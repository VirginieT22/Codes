/********************************
 * Fichier reminderEnfile.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <fcntl.h>		/* For O_* constants */
#include <sys/stat.h>		/* For mode constants */
#include <mqueue.h>		/* For mqd_t */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]){
  const char *usage = "Syntaxe : %s tache_a_ajouter priorite \n avec 1<=priorite<=10 \n"; // Message d'erreur si prg mal utilisé
  mqd_t mq; // Pour descripteur file
  int returnValue; // Pour valeur retour écriture

  /* Vérification a minima que prg bien appelé */
  if (argc != 3 || (atoi(argv[2]) < 1) || (atoi(argv[2]) > 10)) {
    fprintf(stderr, usage, argv[0]);
    return EXIT_FAILURE;
  }
  /* Création ou ouverture de la file (ouvre seulement si existe déjà) */
  mq = mq_open("/mqReminder", O_WRONLY|O_CREAT, 0644, NULL);
  if (mq == (mqd_t) - 1) {
    perror("Erreur d'ouverture de la file /mqReminder");
    return EXIT_FAILURE;
  }
  /* Ecriture de la tâche dans la file */
  returnValue = mq_send(mq, argv[1], (size_t) strlen(argv[1]), (unsigned int)atoi(argv[2]));
  if (returnValue == -1) {
    perror("Erreur d'écriture dans la file /mqReminder");
    return EXIT_FAILURE;
  }
  return EXIT_SUCCESS;
}
