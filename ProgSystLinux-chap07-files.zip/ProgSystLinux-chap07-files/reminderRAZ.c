/********************************
 * Fichier reminderRAZ.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <fcntl.h>		/* For O_* constants */
#include <sys/stat.h>		/* For mode constants */
#include <mqueue.h>		/* For mqd_t */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

int main(){
  int returnValue;
  returnValue = mq_unlink("/mqReminder");
  if (returnValue == -1) {
    if (errno==ENOENT){
      printf("La file n'existe pas ou déjà plus (RAZ ok).\n");}
    return EXIT_SUCCESS; // Pas une erreur pour RAZ
  } else {    
    perror("Erreur suppression file \"/mqReminder\"");
    return EXIT_FAILURE; // RAZ non effectuée
  } 
  return EXIT_SUCCESS;
}
