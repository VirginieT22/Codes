/********************************
 * Fichier client1.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <fcntl.h>		/* For O_* constants */
#include <sys/stat.h>		/* For mode constants */
#include <mqueue.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// *******************************************************************************
// Le processus client cree la file de messages nommée mqRequest 
// et y place le numero de departement a traduire.
// *********************************************************************************

// ATTENTION A NE PAS OUBLIER L'OPTION DE COMPILATION -lrt AU MOMENT DE LA COMPILATION !!!
// Utilisation : lancer le client avec ./client1 num_dept (écrit le numero de dept dans la file)

int main(int argc, char *argv[]){
  mqd_t mq; // Pour descripteur file
  int returnValue; // Pour valeur retour mq_send
  
  if (argc != 2){
    fprintf(stderr,"Syntaxe : %s num_dept où 0<num_dept<20\n", argv[0]);
    exit(EXIT_FAILURE);
  } 
  // On pourrait aussi vérifier que argv[1] est un chiffre entre 1 et 19
  
  /* Ouverture de la file créée par le serveur */
  mq = mq_open("/mqRequest", O_WRONLY);
  if (mq == (mqd_t) -1) {
    perror("Erreur d'ouverture de la file /mqRequest\n");
    exit(EXIT_FAILURE);
  }
  
  /* Ecriture dans la file */
  // argv[1] est une chaîne de caractères contenant le numero de dept, la longueur du message est de la longueur de la chaîne plus un caractère pour transmettre le caractère de fin chaîne \0
  returnValue = mq_send(mq, argv[1], strlen(argv[1])+1, 1);
  if (returnValue == -1) {
    perror("Erreur d'écriture dans la file mq_send\n");
    exit(EXIT_FAILURE);
  }
  exit(EXIT_SUCCESS); 
}
