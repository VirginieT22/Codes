/********************************
 * Fichier reminderDefile.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <fcntl.h>		/* For O_* constants */
#include <sys/stat.h>		/* For mode constants */
#include <mqueue.h>		/* For mqd_t type */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){
  mqd_t mq; // Pour descripteur de la file
  int returnValue; // Pour val retour de primitives
  ssize_t n; // Pour val retour de mq_receive (nb octets lus)
  struct mq_attr attr; // Pour récupération taille message
  char *buffer = NULL; // Buffer de récupération message
  unsigned int priorite, new_priorite; // Priorités ancienne et nouvelle
  char reponse = 'n'; // Pour réponse utilisateur

  /* Ouverture de la file de messages pour lecture ET écriture */
  mq = mq_open("/mqReminder", O_RDWR, 0644, NULL);
  if (mq==(mqd_t)-1) {
    perror("mq_open /mqReminder");
    exit(EXIT_FAILURE);
  }

  /* Allocation de la taille du buffer (taille d'un entier) */
  returnValue = mq_getattr(mq, &attr);
  if (returnValue != 0) {perror("mq_getattr"); exit(EXIT_FAILURE);}
  buffer = (char *)malloc((size_t) attr.mq_msgsize);

  /* Récupération du message le plus ancien des plus prioritaires */
  n = mq_receive(mq, buffer, (size_t) attr.mq_msgsize, &priorite);
  if (n < 0) { perror("mq_receive /mqReminder"); exit(EXIT_FAILURE);}

  /* Affichage de la tâche pour l'utilisateur */
  printf("Tâche : %s, priorite : %d\n", buffer, priorite);
  printf("Conserver cette tâche dans le reminder (o/n, defaut = n) ?\n");
  scanf(" %c", &reponse);

  if (reponse != 'o') {
    /* Cas 1 : l'utilisateur dépile la tâche */
    printf("=> Tâche dépilée.\n");
  } else {
    /* Cas 2 : l'utilisateur renfile la tâche */
    printf("Entrez la nouvelle priorité de la tâche (défaut=ancienne)\n");
    returnValue = scanf("%u", &new_priorite);
    if ((returnValue != 1) || (priorite < 1) || (priorite > 10)) {
      new_priorite = priorite;
    }
    // On remet la tâche dans la file avec la nouvelle priorité 
    returnValue = mq_send(mq, buffer, strlen(buffer), new_priorite);
    if (returnValue!= 0) {
      perror("Erreur d'écriture dans la file /mqReminder \n");
      exit(EXIT_FAILURE);
    }
    printf("Tâche conservée avec la priorité %u.\n", new_priorite);
  }
  return EXIT_SUCCESS;
}
