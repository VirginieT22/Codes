/********************************
 * Fichier renvoieNomDept.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *trad_dept(int); // définie plus bas

int main(int argc, char *argv[]){
  int num_dept; // pour stocker le num de dept
  char *nom_dept; // pour stocker le nom de dept
  char *usage = "Syntaxe : %s num_dept\n où 0<num_dept<20\n";

  // Si nombre d'arguments diff de 2 : erreur
  if (argc != 2) {
    fprintf(stderr, usage, argv[0]);
    exit(EXIT_FAILURE);
  }
  // num de type ascii à type integer
  num_dept = atoi(argv[1]); 
  // si nombre non compris entre 1 et 19 alors erreur
  if (num_dept < 1 || num_dept > 19) {
    fprintf(stderr, usage, argv[0]);
    exit(EXIT_FAILURE);
  }
  // Traduction
  nom_dept = trad_dept(num_dept);
  // Affichage du résultat
  printf("Le nom du departement numero %d est \"%s\".\n", num_dept, nom_dept);
  exit(EXIT_SUCCESS);
}

// Fonction implantant la traduction
char *trad_dept(int num_dept){
  char *strdepartement[20] = {"NA", "Ain", "Aisne", "Allier", "Alpes-de-Haute-Provence", "Hautes-Alpes", "Alpes-Maritimes", "Ardèche", "Ardennes", "Ariège", "Aube", "Aude","Aveyron","Bouches-du-Rhône", "Calvados", "Cantal", "Charente", "Charente-Maritime","Cher", "Corrèze"};
  if (num_dept < 1 || num_dept > 19){
    return "Entrée ton traitable"; }
    else { return strdepartement[num_dept];}
}
