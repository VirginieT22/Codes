/********************************
 * Fichier reminderRAZV1.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <fcntl.h>		/* For O_* constants */
#include <sys/stat.h>		/* For mode constants */
#include <mqueue.h>		/* For mqd_t */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){
  mq_unlink("/mqReminder");
  exit(EXIT_SUCCESS);
}
