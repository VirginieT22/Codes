/********************************
 * Fichier serveur1.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <fcntl.h>		/* For O_* constants */
#include <sys/stat.h>		/* For mode constants */
#include <mqueue.h>		/* For mqd_t type */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// *******************************************************************************
// Le processus serveur lit les données de la file de messages nommée mqRequest 
// censée contenir un numero de departement (placé dans la file par le processus client) 
// et renvoie le résultat de la traduction.
// *********************************************************************************

// ATTENTION A NE PAS OUBLIER L'OPTION DE COMPILATION -lrt AU MOMENT DE LA COMPILATION !!!

char *trad_dept(int);

int main() {
  int num_dept; // Pour num dept
  char *nom_dept; // Pour nom dept
  mqd_t mq; // Pour descripteur file
  struct mq_attr attr; // Pour attributs file
  unsigned int priorite_message_lu; // Pour priorité message reçu
  ssize_t nbOctetsRecus; // Nb octets message reçu

  printf("[Log] SERVEUR - Démarrage\n");
  /* Creation et ouverture O_RDONLY de la file de messages */
  mq=mq_open("/mqRequest",O_RDONLY|O_CREAT,0644,NULL);
  if (mq == (mqd_t) -1) {
    perror("Erreur création ou ouverture file /mqRequest");
    exit(EXIT_FAILURE);
  } else printf("[Log] SERVEUR - File /mqRequest créée\n");

  /* Allocation de la taille du buffer (taille d'un entier) */
  if (mq_getattr(mq, &attr) != 0) {
    perror("mq_getattr");
    exit(EXIT_FAILURE);
  }
  char *buffer;
  buffer = (char *)malloc((size_t) attr.mq_msgsize);
  printf("[Log] SERVEUR - prêt\n");
  while (1) {
   /*Récupération du num de dept le plus ancien des plus prioritaires*/
    nbOctetsRecus = mq_receive(mq, buffer, (size_t) attr.mq_msgsize,&priorite_message_lu);
    if (nbOctetsRecus == -1) {
      perror("[Log] SERVEUR - Erreur receive file /mqRequest");
      exit(EXIT_FAILURE);
    }
    /* num type ascii vers integer */
    num_dept = atoi(buffer);
    /* on pourrait tester ici que le num est compris entre 1 et 19  */
    nom_dept = trad_dept(num_dept);
    printf("SERVEUR - Le nom du departement numero %d est \"%s\".\n", num_dept, nom_dept);
  } // Fin while
  return EXIT_SUCCESS; // Pas atteint mais compil plus propre
} // Fin main

char *trad_dept(int num_dept)
{
  char *strdepartement[20] = { "NA", "Ain", "Aisne", "Allier", "Alpes-de-Haute-Provence", "Hautes-Alpes", "Alpes-Maritimes", "Ardèche", "Ardennes", "Ariège", "Aube", "Aude", "Aveyron", "Bouches-du-Rhône", "Calvados", "Cantal", "Charente", "Charente-Maritime", "Cher", "Corrèze" };
  if (num_dept < 1 || num_dept > 19){
    return "Entrée ton traitable";}
  else { return strdepartement[num_dept]; }
}
