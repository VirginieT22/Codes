/********************************
 * Fichier tableau_ss_semaphores.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include<fcntl.h>		// O_CREAT, ...

#define N 100

volatile char synchro = 0;
volatile long int table[N];

void *min(void *min_bound)
{
	int i;
	long int min = (long int)min_bound;

	fprintf(stdout, "Thread 1 enqueste sur les minima messire... \n");

	for (i = 0; i < N; i++) {
		if (table[i] < min)
			table[i] = min;
		fprintf(stdout, "Thread 1 est en sc \n");
		fflush(stdout);
	}

	pthread_exit(NULL);
	// return NULL;
}

void *max(void *max_bound)
{
	int i;
	long int max = (long int)max_bound;

	fprintf(stdout, "Thread 2 enqueste sur les maxima messire... \n");

	for (i = 0; i < N; i++) {
		if (table[i] > max)
			table[i] = max;
		fprintf(stdout, "Thread 2 est en sc \n");
		fflush(stdout);
	}

	pthread_exit(NULL);
	// return NULL;
}

int main(void)
{
	int i;
	pthread_t filsA, filsB;

	for (i = 0; i < N; i++)
		table[i] = rand() % N;

	fprintf(stdout, "Notre joli tableau contient les valeurs suivantes : \n");

	for (i = 0; i < N; i++)
		fprintf(stdout, "Val %d = %ld\n", i, table[i]);

	fprintf(stdout, "Les threads commencent leur travail... \n");

	if (pthread_create(&filsA, NULL, min, (void *)40L)) {
		perror("pthread_create");
		exit(EXIT_FAILURE);
	}
	if (pthread_create(&filsB, NULL, max, (void *)60L)) {
		perror("pthread_create");
		exit(EXIT_FAILURE);
	}

	if (pthread_join(filsA, NULL))
		perror("pthread_join");

	if (pthread_join(filsB, NULL))
		perror("pthread_join");

	fprintf(stdout,
		"Les threads ont fini leur travail, voici les nouvelles valeurs dans le tableau : \n");

	for (i = 0; i < N; i++)
		fprintf(stdout, "Val %d = %ld\n", i, table[i]);

	exit(EXIT_SUCCESS);
}
