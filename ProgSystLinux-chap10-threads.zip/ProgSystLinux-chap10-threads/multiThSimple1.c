/********************************
 * Fichier multiThSimple1.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(void){
  int i;
  // Ce code est exécuté par un thread exécute: le main thread
  for(i=1;i<=4;i++){
    printf("Thread principal (%d/4)\n", i);
    sleep(1);
  }
  exit(EXIT_SUCCESS);
}

