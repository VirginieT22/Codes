/********************************
 * Fichier tableau.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#define N 100

volatile char synchro = 0;
volatile long int table[N];

void *min(void *min_bound)
{
	int i;
	long int min = (long int)min_bound;

	fprintf(stdout, "Thread 1 enqueste sur les minima messire... \n");

	for (i = 0; i < N; i++) {
		//sleep(1);
		while (synchro == 1) ;	/* attendre mon tour */
		if (table[i] < min) {
			table[i] = min;
			fprintf(stdout, "remplacement par min\n");
		}
		synchro = 1;	/* donner le tour */
	}
	fprintf(stdout, "Fin thread min\n");
	pthread_exit(NULL);
	// return NULL;
}

void *max(void *max_bound)
{
	int i;
	long int max = (long int)max_bound;

	fprintf(stdout, "Thread 2 enqueste sur les maxima messire... \n");

	for (i = 0; i < N; i++) {
		//sleep(1);
		while (synchro == 0) ;	/* attendre */
		if (table[i] > max) {
			table[i] = max;
			fprintf(stdout, "remplacement par max\n");
		}
		synchro = 0;	/* donner le tour */
	}
	fprintf(stdout, "Fin thread max\n");
	pthread_exit(NULL);
	// return NULL;
}

int main(void)
{
	int i;
	pthread_t filsA, filsB;

	for (i = 0; i < N; i++) {
		srand((unsigned int)getpid());
		table[i] = rand() % N;
	}

	fprintf(stdout, "Notre joli tableau contient les valeurs suivantes : \n");

	for (i = 0; i < N; i++)
		fprintf(stdout, "Val %d = %ld\n", i, table[i]);

	fprintf(stdout, "Les threads commencent leur travail... \n");

	if (pthread_create(&filsA, NULL, min, (void *)40L)) {
		perror("pthread_create");
		exit(EXIT_FAILURE);
	}
	if (pthread_create(&filsB, NULL, max, (void *)60L)) {
		perror("pthread_create");
		exit(EXIT_FAILURE);
	}

	if (pthread_join(filsA, NULL))
		perror("pthread_join");

	if (pthread_join(filsB, NULL))
		perror("pthread_join");

	fprintf(stdout,
		"Les threads ont fini leur travail, voici les nouvelles valeurs dans le tableau : \n");

	for (i = 0; i < N; i++)
		fprintf(stdout, "Val %d = %ld\n", i, table[i]);

	printf("Fin du popo !\n");
	return (EXIT_SUCCESS);
}
