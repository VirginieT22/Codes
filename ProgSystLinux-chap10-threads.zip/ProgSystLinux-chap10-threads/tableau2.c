/********************************
 * Fichier tableau2.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/types.h>
#include <unistd.h>

#define N 100
volatile char theChar = '\0';
volatile char synchro = 0;
volatile long int table[N];
pthread_t th1, th2, th3;

void *min(void *min_bound)
{
	int i;
	long int min = (long int)min_bound;

	fprintf(stdout, "Thread 1 enqueste sur les minima messire... \n");

	for (i = 0; i < N; i++) {
		while (synchro == 1) ;	/* attendre mon tour */
		if (table[i] < min)
			table[i] = min;
		synchro = 1;	/* donner le tour */
	}

	pthread_exit(NULL);
	// return NULL;
}

void *max(void *max_bound)
{
	int i;
	long int max = (long int)max_bound;

	fprintf(stdout, "Thread 2 enqueste sur les maxima messire... \n");

	for (i = 0; i < N; i++) {
		while (synchro == 0) ;	/* attendre */
		if (table[i] > max)
			table[i] = max;
		synchro = 0;	/* donner le tour */
	}

	pthread_exit(NULL);
	return NULL;
}

void *display()
{
	int i;

	if (pthread_join(th1, NULL))
		perror("pthread_join");

	if (pthread_join(th2, NULL))
		perror("pthread_join");

	fprintf(stdout,
		"Les threads ont fini leur travail, voici les nouvelles valeurs dans le tableau : \n");

	for (i = 0; i < N; i++)
		fprintf(stdout, "Val %d = %ld\n", i, table[i]);

	pthread_exit(NULL);
	// return NULL;
}

int main(void)
{
	int i;

	for (i = 0; i < N; i++) {
		srand((unsigned int)getpid());
		table[i] = rand() % N;
	}

	fprintf(stdout, "Notre joli tableau contient les valeurs suivantes : \n");

	for (i = 0; i < N; i++)
		fprintf(stdout, "Val %d = %ld\n", i, table[i]);

	fprintf(stdout, "Les threads commencent leur travail... \n");

	if (pthread_create(&th1, NULL, min, (void *)40L)) {
		perror("pthread_create 1");
		exit(EXIT_FAILURE);
	}
	if (pthread_create(&th2, NULL, max, (void *)60L)) {
		perror("pthread_create 2");
		exit(EXIT_FAILURE);
	}

	if (pthread_create(&th3, NULL, display, NULL)) {
		perror("pthread_create 3");
		exit(EXIT_FAILURE);
	}

	if (pthread_join(th3, NULL))
		perror("pthread_join");

	printf("Fin du popo !\n");
	return (EXIT_SUCCESS);
}
