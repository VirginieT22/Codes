/********************************
 * Fichier createThreads1_recupexit.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void *routineThread(void *arg);

int main(void)
{
  pthread_t thr1, thr2, thr3;
  int i,returnValue;
  void * valRetThr=NULL;
  long int valRetThrInt;
  
  returnValue=pthread_create(&thr1, NULL, routineThread, (void *)1L);
  if (returnValue != 0) {
    fprintf(stderr, "Erreur pthread_create premier thread\n");
  }
  returnValue=pthread_create(&thr2, NULL, routineThread, (void *)2L);
  if (returnValue != 0) {
    fprintf(stderr, "Erreur pthread_create deuxième thread\n");
  }
  returnValue=pthread_create(&thr3, NULL, routineThread, (void *)3L);
  if (returnValue != 0) {
    fprintf(stderr, "Erreur pthread_create troisième thread\n");
  }
  for(i=1;i<=4;i++){
    printf("Thread principal (%d/4)\n", i);
    sleep(1);
  }
  pthread_join(thr1,&valRetThr);
  valRetThrInt = (long)valRetThr; // cast void * -> long int
  printf("Val retour thread 1 : %ld\n", valRetThrInt);
  pthread_join(thr2,&valRetThr);
  valRetThrInt = (long)valRetThr; // cast void * -> long int
  printf("Val retour thread 2 : %ld\n", valRetThrInt);
  pthread_join(thr3,&valRetThr);
  valRetThrInt = (long)valRetThr; // cast void * -> long int
  printf("Val retour thread 3 : %ld\n", valRetThrInt);
  exit(EXIT_SUCCESS);
}

void * routineThread(void *arg)
{
  long int num = (long)arg;
  int i;
  for(i=1;i<=6;i++){
    printf("Thread numero %ld (%d/6)\n", num, i);
    sleep(1);
  }
  return (void *) num;
}
