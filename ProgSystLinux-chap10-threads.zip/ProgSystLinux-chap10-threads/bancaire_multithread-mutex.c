/********************************
 * Fichier bancaire_multithread-mutex.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <pthread.h>

void * virement (void *);
void * calcul_somme (void *);
void * calcul_moyenne (void *);

int cpt1, cpt2; // variables stockant le contenu des comptes
int somme; // resultat de la somme des deux comtes
double moyenne; // resultat de la val moyenne des deux comptes

// (NEW) Déclaration des sémaphores pthread_mutex
pthread_mutex_t mutex_acces_compte1 = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mutex_acces_compte2 = PTHREAD_MUTEX_INITIALIZER;

int main (int argc, char * argv[]){
  pthread_t thr1, thr2, thr3;
  int valRetour;
  
  // Instanciation du contenu des comptes
  cpt1 = 200; fprintf(stdout, "Solde du compte 1  : %d\n", cpt1);
  cpt2 = 100; fprintf(stdout, "Solde du compte 2  : %d\n", cpt2);

  // Création des threads
  valRetour = pthread_create(&thr1, NULL, virement, (void *)1L);
  if (valRetour != 0) {
    perror("Erreur dans pthread_create thr1\n");
    exit(EXIT_FAILURE);
  }
  valRetour = pthread_create(&thr2, NULL, calcul_somme, (void *)2L);
  if (valRetour != 0) {
    perror("Erreur dans pthread_create thr2\n");
    exit(EXIT_FAILURE);
  }
  valRetour = pthread_create(&thr3, NULL, calcul_moyenne, (void *)3L);
  if (valRetour != 0) {
    perror("Erreur dans pthread_create thr2\n");
    exit(EXIT_FAILURE);
  }

  // Terminaison
  pthread_join(thr1,NULL);
  pthread_join(thr2,NULL);
  pthread_join(thr3,NULL);

  // (NEW) Destruction des sémaphores
  pthread_mutex_destroy(&mutex_acces_compte1);
  pthread_mutex_destroy(&mutex_acces_compte2);
    
  return EXIT_SUCCESS;
} // Fin main

void * virement (void * arg){
  fprintf(stdout, "(Thr %ld) Lancement thread virement \n", (long int) arg);
  pthread_mutex_lock(&mutex_acces_compte1); // (NEW)
  pthread_mutex_lock(&mutex_acces_compte2); // (NEW)
  fprintf(stdout, "(Thr %ld) Debit de 50 euros du cpt 1 \n", (long int) arg);
  cpt1 = 200-50;
  sleep(3); // Simulation d'un temps de réponse du SI bancaire
  cpt2 = 100+50;
  sleep(3); // Simulation d'un temps de réponse du SI bancaire
  fprintf(stdout, "(Thr %ld) Credit de 50 euros sur le cpt 2 \n", (long int) arg);
  fprintf(stdout, "(Thr %ld) Fin du virement \n", (long int) arg);
  pthread_mutex_unlock(&mutex_acces_compte1); // (NEW)
  pthread_mutex_unlock(&mutex_acces_compte2); // (NEW)
  pthread_exit(EXIT_SUCCESS);
}

void * calcul_somme (void * arg){
  fprintf(stdout, "(Thr %ld) Lancement thread calcul de la somme \n", (long int) arg);
  // Calcul de la somme des deux comptes
  sleep(1); // Simulation du temps de lancement du fils
  pthread_mutex_lock(&mutex_acces_compte1); // (NEW)
  pthread_mutex_lock(&mutex_acces_compte2); // (NEW)
  somme = cpt1 + cpt2; sleep(2);// Calcul de somme des cpts
  fprintf(stdout, "(Thr %ld) La somme des comptes est : %d\n", (long int) arg, somme);
  fprintf(stdout, "(Thr %ld) Fin du calcul de la somme \n", (long int) arg);
  pthread_mutex_unlock(&mutex_acces_compte1); // (NEW)
  pthread_mutex_unlock(&mutex_acces_compte2); // (NEW)
  pthread_exit(EXIT_SUCCESS);
}

void * calcul_moyenne (void * arg){
  fprintf(stdout, "(Thr %ld) Lancement thread calcul de la moyenne \n", (long int) arg);
  // Calcul de la somme des deux comptes
  sleep(1); // Simulation du temps de lancement du fils
  pthread_mutex_lock(&mutex_acces_compte1); // (NEW)
  pthread_mutex_lock(&mutex_acces_compte2); // (NEW)
  moyenne = (cpt1 + cpt2) / 2.0; sleep(2); // Calcul de moyenne des cpts
  fprintf(stdout, "(Thr %ld) La moyenne des comptes est : %f\n", (long int) arg, moyenne);
  pthread_mutex_unlock(&mutex_acces_compte1); // (NEW)
  pthread_mutex_unlock(&mutex_acces_compte2); // (NEW)
  fprintf(stdout, "(Thr %ld) Fin du calcul de la moyenne \n", (long int) arg);
  pthread_exit(EXIT_SUCCESS);
}

