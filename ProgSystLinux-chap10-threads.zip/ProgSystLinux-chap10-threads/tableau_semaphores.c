/********************************
 * Fichier tableau_semaphores.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include<fcntl.h>		// O_CREAT, ...
#include <semaphore.h>		// Semaphores
#include <sys/types.h>
#include <unistd.h>

/**************************************************/
/*Note : On fait ici appel aux sémaphores présentés dans le cours. Dans un cas réel, le mécanisme de cet exemple devrait être remplaçé par un véritable mutex (cf. pthread_mutex_t et les fonctions associées).*/
/**************************************************/

#define N 100

volatile char synchro = 0;
volatile long int table[N];
sem_t *semlock_min;
sem_t *semlock_max;

void *min(void *min_bound)
{
	int i;
	long int min = (long int)min_bound;

	fprintf(stdout, "Thread 1 enqueste sur les minima messire... \n");

	for (i = 0; i < N; i++) {
		sem_wait(semlock_min);	/* Entrée en section critique */
		if (table[i] < min)
			table[i] = min;
		fprintf(stdout, "Thread 1 est en sc \n");
		fflush(stdout);
		sem_post(semlock_max);	/* Sortie de la section critique */
	}

	pthread_exit(NULL);
	// return NULL;
}

void *max(void *max_bound)
{
	int i;
	long int max = (long int)max_bound;

	fprintf(stdout, "Thread 2 enqueste sur les maxima messire... \n");

	for (i = 0; i < N; i++) {
		sem_wait(semlock_max);	/* Entrée en section critique */
		if (table[i] > max)
			table[i] = max;
		fprintf(stdout, "Thread 2 est en sc \n");
		fflush(stdout);
		sem_post(semlock_min);	/* Sortie de la section critique */
	}

	pthread_exit(NULL);
	// return NULL;
}

int main(void)
{
	int i;
	pthread_t filsA, filsB;

	semlock_min = sem_open("/mutex_min", O_CREAT, 0644, 1);

	if (semlock_min == SEM_FAILED) {
		perror("sem_open_min");
		exit(EXIT_FAILURE);
	}

	semlock_max = sem_open("/mutex_max", O_CREAT, 0644, 1);

	if (semlock_max == SEM_FAILED) {
		perror("sem_open max");
		exit(EXIT_FAILURE);
	}

	for (i = 0; i < N; i++) {
		srand((unsigned int)getpid());
		table[i] = rand() % N;
	}

	fprintf(stdout, "Notre joli tableau contient les valeurs suivantes : \n");

	for (i = 0; i < N; i++)
		fprintf(stdout, "Val %d = %ld\n", i, table[i]);

	fprintf(stdout, "Les threads commencent leur travail... \n");

	if (pthread_create(&filsA, NULL, min, (void *)40L)) {
		perror("pthread_create");
		exit(EXIT_FAILURE);
	}
	if (pthread_create(&filsB, NULL, max, (void *)60L)) {
		perror("pthread_create");
		exit(EXIT_FAILURE);
	}

	if (pthread_join(filsA, NULL))
		perror("pthread_join");

	if (pthread_join(filsB, NULL))
		perror("pthread_join");

	fprintf(stdout,
		"Les threads ont fini leur travail, voici les nouvelles valeurs dans le tableau : \n");

	for (i = 0; i < N; i++)
		fprintf(stdout, "Val %d = %ld\n", i, table[i]);

	if (sem_unlink("/mutex_min") == -1) {
		perror("sem_unlink min");
		exit(EXIT_FAILURE);
	}

	if (sem_close(semlock_min) == -1) {
		perror("sem_close min");
		exit(EXIT_FAILURE);
	}

	if (sem_unlink("/mutex_max") == -1) {
		perror("sem_unlink max");
		exit(EXIT_FAILURE);
	}

	if (sem_close(semlock_max) == -1) {
		perror("sem_close max");
		exit(EXIT_FAILURE);
	}

	exit(EXIT_SUCCESS);
}
