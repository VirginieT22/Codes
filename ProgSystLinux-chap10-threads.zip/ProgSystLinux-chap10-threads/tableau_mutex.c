/********************************
 * Fichier tableau_mutex.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <fcntl.h>		// O_CREAT, ...
#include <semaphore.h>		// Semaphores
#include <sys/types.h>
#include <unistd.h>

#define N 100

volatile char synchro = 0;
volatile long int table[N];
int x;
pthread_mutex_t mut = PTHREAD_MUTEX_INITIALIZER;

void *min(void *min_bound)
{
	int i;
	long int min = *((int *)min_bound);

	fprintf(stdout, "Thread 1 enqueste sur les minima messire... \n");

	for (i = 0; i < N; i++) {
		pthread_mutex_lock(&mut);	/* Entrée en section critique */
		if (table[i] < min)
			table[i] = min;
		fprintf(stdout, "Thread 1 est en sc \n");
		fflush(stdout);
		pthread_mutex_unlock(&mut);	/* Sortie de la section critique */
	}

	pthread_exit(NULL);
	// return NULL;
}

void *max(void *max_bound)
{
	int i;
	long int max = *((int *)max_bound);

	fprintf(stdout, "Thread 2 enqueste sur les maxima messire... \n");

	for (i = 0; i < N; i++) {
		pthread_mutex_lock(&mut);	/* Entrée en section critique */
		if (table[i] > max)
			table[i] = max;
		fprintf(stdout, "Thread 2 est en sc \n");
		fflush(stdout);
		pthread_mutex_unlock(&mut);	/* Sortie de la section critique */
	}

	pthread_exit(NULL);
	// return NULL;
}

int main(void)
{
	int i, min_bound, max_bound;
	pthread_t th1, th2;

	for (i = 0; i < N; i++) {
		srand((unsigned int)getpid());
		table[i] = rand() % N;
	}

	fprintf(stdout, "Notre joli tableau contient les valeurs suivantes : \n");

	for (i = 0; i < N; i++)
		fprintf(stdout, "Val %d = %ld\n", i, table[i]);

	fprintf(stdout, "Les threads commencent leur travail... \n");

	min_bound = 40;
	if (pthread_create(&th1, NULL, min, (void *)&min_bound)) {
		perror("pthread_create");
		exit(EXIT_FAILURE);
	}
	max_bound = 60;
	if (pthread_create(&th2, NULL, max, (void *)&max_bound)) {
		perror("pthread_create");
		exit(EXIT_FAILURE);
	}

	if (pthread_join(th1, NULL))
		perror("pthread_join");

	if (pthread_join(th2, NULL))
		perror("pthread_join");

	fprintf(stdout,
		"Les threads ont fini leur travail, voici les nouvelles valeurs dans le tableau : \n");

	for (i = 0; i < N; i++)
		fprintf(stdout, "Val %d = %ld\n", i, table[i]);

	exit(EXIT_SUCCESS);
}
