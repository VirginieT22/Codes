/********************************
 * Fichier rechercheTab2Threads.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h>  /* stderr, stdout, fprintf, perror */
#include <stdlib.h> /* exit */
#include <unistd.h> /* sleep */
#include <pthread.h>

size_t taille_tableau;
long int * tableau;


/**
 * @brief réserve la mémoire pour n valeurs entières
 * @param entier n nombre de cases mémoire à réserver
 * @return adresse du tableau
 */
long int *creer_tableau_vide_entier()
{
  long int * tableau = malloc(taille_tableau * sizeof(long int));
	
  if (tableau == NULL) {
    perror("Malloc tableau\n");
    exit(EXIT_FAILURE);
  } else {
    return tableau;
  }
}

/**
 * @brief lis sur l'entrée standard 1 valeur entière et la stocke dans un tableau, dans une case précise
 * @param tableau d'entier, indice de la case destination
 */
void remplir_case_entier(size_t i)
{
  fprintf(stdout, "élément %ld : ", i);
  scanf("%ld", &(tableau[i]));
}

/**
 * @brief lis sur l'entrée standard n valeur entières et les stockent dans un tableau
 * @param entier n nombre de cases mémoire du tableau, tableau d'entier
 */
void remplir_tableau_entier()
{
  size_t i;

  for (i = 0; i < taille_tableau; i++) {
    remplir_case_entier(i);
  }
}

/**
 * @brief recherche une valeur dans un tableau d'entier sur une plage d'indices 
 * @param entier val valeur à rechercher, tableau d'entier, indice de début de zone de recherche inclu, indice de fin de zone de recherche exclu
 */
void *rechercher_tableau_entier_partie1(void *arg)
{
  size_t i;
  long int val = (long int) arg; //Transtypage argument

  for (i = 0; i < (taille_tableau/2); i++) {
    sleep(1);
    if (val == tableau[i]) {
      fprintf(stdout, "Thread 1 a TROUVE !\n\n");
      pthread_exit(NULL); // <- termine le thread seulement
      // exit(EXIT_SUCCESS); // <- termine le processus (Q2)
    }
  }
  fprintf(stdout, "Thread 1 n'a pas trouve !\n\n");   
  pthread_exit(NULL); // <- (non trouvé) termine le thread seul
}

void *rechercher_tableau_entier_partie2(void *arg)
{
  size_t j;
  long int val = (long int) arg; // Transtypage argument

  for (j = (taille_tableau/2); j < taille_tableau; j++) {
    sleep(1);
    if (val == tableau[j]) {
      fprintf(stdout, "Thread 2 a TROUVE !\n\n");
      pthread_exit(NULL); // <- termine le thread seulement
      // exit(EXIT_SUCCESS); // <- termine le processus (Q2)
    }
  }
  fprintf(stdout, "Thread 2 n'a pas trouve !\n\n");   
  pthread_exit(NULL); // <- (non trouvé) termine le thread seul
}


/**
 * @brief recherche sur 2 fils dans un tableau d'entier
 */
int main()
{
  size_t n;
  int val;
  long int valLong;
  pthread_t thr1, thr2;
  int valRetour;

  fprintf(stdout, "Taille du tableau à renseigner : \n");
  scanf("%lu", &n);
  taille_tableau=n;

  tableau = creer_tableau_vide_entier();
  remplir_tableau_entier();

  printf("Elément à rechercher : ");
  scanf("%d", &val);
  valLong= (long int) val;

  valRetour = pthread_create(&thr1, NULL, rechercher_tableau_entier_partie1, (void *) valLong);
  if (valRetour != 0) {
    perror("Erreur dans pthread_create thr1\n");
    exit(EXIT_FAILURE);
  }

  valRetour = pthread_create(&thr2, NULL, rechercher_tableau_entier_partie2, (void *) valLong);
  if (valRetour != 0) {
    perror("Erreur dans pthread_create thr2\n");
    exit(EXIT_FAILURE);
  }

  // Ne pas oublier les appels de pthread_join, faute de quoi le thread 
  // principal  demande la terminaison du processus (avec tous les  
  // autres threads), apres la creation des deux threads de recherche.
  pthread_join(thr1, NULL);
  pthread_join(thr2, NULL);
  exit(EXIT_SUCCESS);
  // A la place des trois dernières instructions, on aurait pu
  // utiliser pthread_exit dans le thread principal
}
