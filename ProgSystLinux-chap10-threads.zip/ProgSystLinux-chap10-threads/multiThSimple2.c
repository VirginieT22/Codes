/********************************
 * Fichier multiThSimple2.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void * routineThread(void *arg){
  int i;
  for(i=1;i<=6;i++){
    printf("Thread supplementaire (%d/6)\n", i);
    sleep(1);
  }
  return EXIT_SUCCESS;
}

int main(void){
  pthread_t newthr;
  int i, returnValue;

  // Création d'un thread supplémentaire
  returnValue=pthread_create(&newthr,NULL,routineThread,NULL);
  if (returnValue != 0) {
    fprintf(stderr, "Erreur pthread_create thread supp\n");
  }
  // Affichages effectués par le thread principal
  for(i=1;i<=4;i++){
    printf("Thread principal (%d/4)\n", i);
    sleep(1);
  }
  pthread_exit(EXIT_SUCCESS); // c.f. Question 3
} // fin main
