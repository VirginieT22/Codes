/********************************
 * Fichier multiThSimple3.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void * routineThread(void *arg){
  int i;
  for(i=1;i<=6;i++){
    printf("Thread supplémentaire (%d/6)\n", i);
    sleep(1);
  }
  return EXIT_SUCCESS;
}

int main(void){
  pthread_t thr1, thr2, thr3;
  int i, returnValue;

  // Création du premier thread supplémentaire
  returnValue=pthread_create(&thr1,NULL,routineThread,NULL);
  if (returnValue != 0) {
    fprintf(stderr, "Erreur pthread_create premier thread\n");
  }
  // Création du deuxième thread supplémentaire
  returnValue=pthread_create(&thr2,NULL,routineThread,NULL);
  if (returnValue != 0) {
    fprintf(stderr, "Erreur pthread_create deuxième thread\n");
  }
  // Création du troisième thread supplémentaire
  returnValue=pthread_create(&thr3,NULL,routineThread,NULL);
  if (returnValue != 0) {
    fprintf(stderr, "Erreur pthread_create troisième thread\n");
  }
  // Affichages effectués par le thread principal
  for(i=1;i<=4;i++){
    printf("Thread principal (%d/4)\n", i);
    sleep(1);
  }
  pthread_exit(EXIT_SUCCESS); // c.f. Question 3
} // fin main
