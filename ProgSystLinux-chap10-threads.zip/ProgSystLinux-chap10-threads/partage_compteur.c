/********************************
 * Fichier partage_compteur.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void *fonction_thread(void *arg);

int compteur = 0;

int main(void)
{
	pthread_t thr1, thr2, thr3, thr4;

	if (pthread_create(&thr1, NULL, fonction_thread, (void *)1) != 0) {
		fprintf(stderr, "Erreur dans pthread_create\n");
		exit(EXIT_FAILURE);
	}
	if (pthread_create(&thr2, NULL, fonction_thread, (void *)2) != 0) {
		fprintf(stderr, "Erreur dans pthread_create\n");
		exit(EXIT_FAILURE);
	}
	if (pthread_create(&thr3, NULL, fonction_thread, (void *)3) != 0) {
		fprintf(stderr, "Erreur dans pthread_create\n");
		exit(EXIT_FAILURE);
	}
	if (pthread_create(&thr4, NULL, fonction_thread, (void *)4) != 0) {
		fprintf(stderr, "Erreur dans pthread_create\n");
		exit(EXIT_FAILURE);
	}
	system("ps m");
	fprintf(stderr, "Thread principal\n");
	sleep(1);
	fprintf(stderr, "Thread principal\n");
	sleep(1);
	fprintf(stderr, "Thread principal\n");
	sleep(1);
	fprintf(stderr, "Thread principal\n");
	sleep(1);
	fprintf(stderr, "Thread principal\n");
	sleep(1);
	return 0;
}

void *fonction_thread(void *arg)
{
	long int num = (long int)arg;
	fprintf(stderr, "Thread numero %ld\n", num);
	compteur++;
	fprintf(stderr, "Nouvelle valeur du compteur : %d\n", compteur);
	fprintf(stderr, "Thread numero %ld\n", num);
	compteur++;
	fprintf(stderr, "Nouvelle valeur du compteur : %d\n", compteur);
	fprintf(stderr, "Thread numero %ld\n", num);
	compteur++;
	fprintf(stderr, "Nouvelle valeur du compteur : %d\n", compteur);
	fprintf(stderr, "Thread numero %ld\n", num);
	compteur++;
	fprintf(stderr, "Nouvelle valeur du compteur : %d\n", compteur);

	return NULL;
}
