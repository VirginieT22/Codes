/********************************
 * Fichier unKilometre.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h>		/* stderr, stdout, fprintf, perror */
#include <unistd.h>		/* fork */
#include <stdlib.h>		/* exit */

int main(void)
{
	int i;
	for (i = 1; i <= 30; i++) {
		printf("(%d) %d km à pied, ca use, ca use. %d km à pied, ca use les souliers. \n", getpid(), i, i);
		sleep(1);
	}
	return (EXIT_SUCCESS);
}
