/********************************
 * Fichier exemple-execv.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h>		/* stderr, stdout, fprintf, perror */
#include <unistd.h>		/* exec */
#include <stdlib.h>		/* EXIT_FAILURE */

int main(void)
{
	char *arg[] = { "ps", "-j", "-a", "-r", (char *)NULL };
	fprintf(stdout, "Je vais lancer ps -j -a -r\n");
	execv("/bin/ps", arg);
	// La suite du code ne sera atteinte qu'en cas d'échec du recouvrement
	perror("Je suis du code exécuté en cas d'echec de l'appel d'execv\n");
	exit(EXIT_FAILURE);
}
