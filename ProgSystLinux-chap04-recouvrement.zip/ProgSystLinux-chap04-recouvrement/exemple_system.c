/********************************
 * Fichier exemple_system.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

int main()
{
	char cmd[150];

	fgets(cmd, sizeof(cmd) / sizeof(char), stdin);
	system(cmd);

	exit(EXIT_SUCCESS);
}
