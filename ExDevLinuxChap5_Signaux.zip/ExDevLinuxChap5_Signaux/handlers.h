/********************************
 * Fichier handlers.c
 * Livre "Exercices corrigés de développement système sous Linux"
 *
 * (c) 2018 P. Alain, J. Chevelu, V. Thion
 *
 ********************************/
// Nouveau gestionnaire
void nouveauGestionnaire(int); 
// Affectation du nouveau gestionnaire à tous les signaux possibles
void affectationGestionnaires(); 
// Procédure de RAZ des gestionnaires au comportement par défaut
void razGestionnaires(); 
