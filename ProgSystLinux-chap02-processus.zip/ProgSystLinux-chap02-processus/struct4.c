/********************************
 * Fichier struct4.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h>		/* stderr, stdout, fprintf */
#include <unistd.h>		/* fork */
#include <sys/wait.h>		/* wait */
#include <stdlib.h>		/* exit */

int main(void)
{
	int i;
	int j = 0;
	for (i = 0; i < 2; i++) {
		fork();
		j++;
		printf("Bonjour ! (moi :%d, mon pere : %d), j=%d\n", getpid(), getppid(), j);
	}
	printf("Bonjour ! (moi :%d, mon pere : %d), j=%d\n", getpid(), getppid(), j);
	wait(NULL);
	exit(0);
}
