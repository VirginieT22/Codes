/********************************
 * Fichier reprez_processRV.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h>		/* printf */
#include <unistd.h>		/* fork */
#include <stdlib.h>		/* EXIT_SUCCESS, EXIT_FAILURE */

int main(void)
{
	pid_t pid_fils = -1;
	int a = 4;
	int b = 3;
	pid_fils = fork();
	if (pid_fils == -1){
	  perror("Echec fork");
	  exit(EXIT_FAILURE);
	}
	a = 5;
	printf("All you need is love\n");
	printf("a==%d b==%d pid_fils==%d\n", a, b, pid_fils);
	exit(EXIT_SUCCESS);
}
