/********************************
 * Fichier struct3.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h>		/* stderr, stdout, fprintf */
#include <unistd.h>		/* fork */
#include <sys/wait.h>		/* wait */
#include <stdlib.h>		/* exit */

int main(void)
{
	fork();
	fork();
	fork();
	printf("Bonjour !\n");
	while (wait(NULL) >= 0) {
	};
	exit(0);
}
