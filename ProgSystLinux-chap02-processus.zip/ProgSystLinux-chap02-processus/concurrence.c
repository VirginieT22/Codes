/********************************
 * Fichier concurrence.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h>		/* stderr, stdout, fprintf, perror */
#include <unistd.h>		/* fork */
#include <sys/wait.h>		/* wait */
#include <stdlib.h>		/* exit */

int main(void)
{
	int i;
	for (i = 1; i < 30; i++) {
		printf("(%d) %d km ..., %d km à pied, ca use les souliers. \n", getpid(), i, i);
		sleep(1);
	}
	return (EXIT_SUCCESS);
}
