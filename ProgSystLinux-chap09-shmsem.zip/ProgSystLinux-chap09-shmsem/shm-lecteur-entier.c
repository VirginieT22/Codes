/********************************
 * Fichier shm-lecteur-entier.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h> // perror
#include <stdlib.h> // exit
#include <unistd.h> // getpid
#include <sys/mman.h> // shm_open, mmap
#include <fcntl.h>  // 0_* flag constants

int main(){
  int fd; // Pour descripteur de la région
  int *compteur; // Variable de rattachement
  /* 1- Ouverture de la region shmEntier en mode LECTURE SEULEMENT */
  fd = shm_open("shmEntier", O_RDWR, 00);
  if (fd == -1) {
    perror("shmEntier");
    exit(EXIT_FAILURE);
  }	
  /* 2- Rattachement de la zone memoire à compteur */
  compteur = mmap(NULL, sizeof(int), PROT_READ, MAP_SHARED, fd, 0);
  if (compteur == MAP_FAILED) {
    perror("mmap");
    exit(EXIT_FAILURE);
  }
  /* 3- Une lecture de la region de memoire partagee */
  fprintf(stdout, "(%d) La zone memoire contient %d. \n", getpid(), (*compteur));
  return EXIT_SUCCESS; // Fin
}
