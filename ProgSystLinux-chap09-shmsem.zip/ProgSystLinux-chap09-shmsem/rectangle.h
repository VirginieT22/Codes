/********************************
 * Fichier rectangle.h
 * Livre "Exercices corrigés de développement système sous Linux"
 *
 * (c) 2018 P. Alain, J. Chevelu, V. Thion
 *
 ********************************/

typedef struct{
   int x ;
   int y ;
} Point ;

typedef struct{
   Point p1 ;
   Point p2 ;
} Rectangle ;
