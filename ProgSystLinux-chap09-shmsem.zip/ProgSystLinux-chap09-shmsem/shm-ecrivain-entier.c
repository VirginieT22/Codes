/********************************
 * Fichier shm-ecrivain-entier.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h> // perror
#include <stdlib.h> // exit
#include <unistd.h> // ftruncate
#include <sys/mman.h> // shm_open, mmap, shm_unlink
#include <fcntl.h>  // 0_* flag constants

int main(){
  int fd; // Pour descripteur de la région
  int val_retour; // Pour val de retour de ftruncate
  int *leCompteur; // Variable de rattachement

  /* 1-Destruction de la zone memoire si elle existait déjà */
  shm_unlink("shmEntier");
  /* 2-Creation de la région de mémoire partagée shmEntier */
  fd = shm_open("shmEntier", O_RDWR | O_CREAT, 0600);
  if (fd == -1) {
    perror("shmEntier");
    exit(EXIT_FAILURE);
  }
  /* 3- Dimensionnement de la zone memoire */
  val_retour = ftruncate(fd, sizeof(int));
  if (val_retour == -1) {
    perror("fruncate");
    exit(EXIT_FAILURE);
  }
  /* 4-Rattachement de la zone memoire à leCompteur */
  leCompteur = mmap(NULL, sizeof(int), PROT_WRITE, MAP_SHARED, fd, 0);
  if (leCompteur == MAP_FAILED) {
    perror("map");
    exit(EXIT_FAILURE);
  }
  /* 5-La valeur 42 est placee dans la region */
  *leCompteur = 42;
  return EXIT_SUCCESS; // Fin
}
