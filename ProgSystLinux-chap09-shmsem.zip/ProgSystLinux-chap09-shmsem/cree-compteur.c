/********************************
 * Fichier cree-compteur.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
// Ce programme peut être exécuté plusieurs fois en parallèle pour
// illustrer un access concurrent a la region de memoire partagée

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>

int main(){
  int fd; // Pour le descripteur de la zone de mémoire partagée
  int *c; // Adresse de rattachement de la mémoire
  int returnValue; // Pour valeur retour ftruncate

  /* 1- Création de la région */
  fprintf(stdout, "[Log] Création shm\n");
  fd = shm_open("compteur", O_RDWR | O_CREAT , 0666);
  if (fd == -1) {
    perror("Echec shm_open\n");
    exit(EXIT_FAILURE);}
  /* 2- Dimensionnement de la région */
  fprintf(stdout, "[Log] Dimensionnement shm\n");
  returnValue=ftruncate(fd, sizeof(int));
  if (returnValue == -1) {
    perror("Echec ftruncate");
    exit(EXIT_FAILURE);}
  /* 3- Rattachement de la région */
  fprintf(stdout, "[Log] Rattachement shm\n");
  c = mmap(NULL,sizeof(int),PROT_READ|PROT_WRITE,MAP_SHARED,fd,0);
  if (c == MAP_FAILED) {
    perror("mmap");
    exit(EXIT_FAILURE);}
  /* 4- Initialisation du compteur et fin */
  fprintf(stdout, "[Log] Initialisation shm\n");
  (*c) = 0;
  return EXIT_SUCCESS;
}
