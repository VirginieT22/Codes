/********************************
 * Fichier incremente-compteur.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
// Ce programme peut être exécuté plusieurs fois en parallèle pour
// illustrer un access concurrent a la region de memoire partagée

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>

int main(){
  int fd; // Pour le descripteur de la zone de mémoire partagée
  int *leCompteur; // Adresse de rattachement de la mémoire
  int i; // Pour structure for

  /* 1- Ouverture de la région, sans création */
  fprintf(stdout, "[Log] Ouverture shm\n");
  fd = shm_open("compteur", O_RDWR, 00);
  if (fd == -1) {
    perror("Echec shm_open");
    exit(EXIT_FAILURE);}
  /* NB : pas de dimensionnement */
  /* 2- Rattachement de la région */
  fprintf(stdout, "[Log] Rattachement shm\n");
  leCompteur = mmap(NULL, sizeof(int), PROT_READ|PROT_WRITE, MAP_SHARED, fd, 0);
  if (leCompteur == MAP_FAILED) {
    perror("mmap");
    exit(EXIT_FAILURE);}
  /* 3- Incrémentation du compteur */
  for (i=0;i<=100;i++) {
    (*leCompteur)++;
    fprintf(stdout, "(PID :%d) compteur = %d\n", getpid(), (*leCompteur));
    sleep(1);
  }
  return EXIT_SUCCESS;
}
