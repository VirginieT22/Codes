/********************************
 * Fichier shm-departements.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
// -----------------------------------------
// Acces concurrent posant probleme
// -----------------------------------------

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>

char *trad_dept(int);

int main(int argc, char *argv[])
{
	int fd;
	int *compteur;
	char *nom_dept;

	// Si besoin de nettoyer, inclure cette commande dans une execution
	// shm_unlink("/memoire");  

	if (argc != 2) {
		fprintf(stderr, "Syntaxe : %s nom_segment\n", argv[0]);
		exit(EXIT_FAILURE);
	}

	if ((fd = shm_open(argv[1], O_RDWR | O_CREAT | O_EXCL, 0666)) == -1) {
		// Echec la creation avec O_EXCL -> la mémoire existe déjà, on l'ouvre simplement
		fd = shm_open(argv[1], O_RDWR, 00);
	} else {
		// La création a réussi donc dimensionnement
		if (ftruncate(fd, sizeof(int)) != 0) {
			perror("ftruncate");
			exit(EXIT_FAILURE);
		}
	}

	compteur = mmap(NULL, sizeof(int), PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
	if (compteur == MAP_FAILED) {
		perror("mmap");
		exit(EXIT_FAILURE);
	}
	while (1) {
		(*compteur)++;
		fprintf(stdout, "(PID :%d) compteur = %d\n", getpid(), (*compteur));
		nom_dept = trad_dept(*compteur);
		fprintf(stdout, "Le nom du departement numero %d est \"%s\".\n", *compteur,
			nom_dept);
		sleep(1);
	}
	exit(EXIT_SUCCESS);
}

char *trad_dept(int num_dept)
{
	switch (num_dept) {
	case 1:
		return "Ain";
	case 2:
		return "Aisne";
	case 3:
		return "Allier";
	case 4:
		return "Alpes-de-Haute-Provence";
	case 5:
		return "Hautes-Alpes";
	case 6:
		return "Alpes-Maritimes";
	case 7:
		return "Ardèche";
	case 8:
		return "Ardennes";
	case 9:
		return "Ariège";
	case 10:
		return "Aube";
	case 11:
		return "Aude";
	case 12:
		return "Aveyron";
	case 13:
		return "Bouches-du-Rhône";
	case 14:
		return "Calvados";
	case 15:
		return "Cantal";
	case 16:
		return "Charente";
	case 17:
		return "Charente-Maritime";
	case 18:
		return "Cher";
	case 19:
		return "Corrèze";
		// Liste incomplete, elle peut facilement etre etendue
	default:
		return "ceci n'est pas un numero de departement de France metropolitaine.\n";
	};
}
