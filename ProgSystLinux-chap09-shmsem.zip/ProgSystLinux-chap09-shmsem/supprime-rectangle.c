/********************************
 * Fichier supprime-rectangle.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>

int main(){
  int returnValue ; // Pour valeur retour shm_unlink

  printf("[Log] Demande de suppression\n");
  returnValue = shm_unlink("monRectangle");
  if (returnValue == -1) {
    perror("[Log] Pas de suppression effectuée (inutile?)\n");
    exit(EXIT_FAILURE);
  } 
  return EXIT_SUCCESS;
}
