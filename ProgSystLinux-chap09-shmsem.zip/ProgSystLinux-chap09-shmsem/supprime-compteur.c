/********************************
 * Fichier supprime-compteur.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
// Ce programme peut être exécuté plusieurs fois en parallèle pour
// illustrer un access concurrent a la region de memoire partagée

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>

int main(){
  int returnValue ; // Pour valeur retour shm_unlink

  printf("[Log] Demande de suppression\n");
  returnValue = shm_unlink("compteur");
  if (returnValue == -1) {
    perror("[Log] Pas de suppression effectuée (inutile?)\n");
    exit(EXIT_FAILURE);
  } 
  return EXIT_SUCCESS;
}
