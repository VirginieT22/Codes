/********************************
 * Fichier instancie-rectangle.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/


#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include "rectangle.h"

int main(int argc, char *argv[]){
  int fd; // Pour le descripteur de la zone de mémoire partagée
  Rectangle *r; // Adresse de rattachement de la mémoire

  /* 1- Vérification des entrées du programme */
  if (argc != 5){
    fprintf(stderr, "Syntaxe : %s p1.x p1.y p2.x p2.y (int)\n", argv[0]);
    exit(EXIT_FAILURE);
  }
  /* 2- Ouverture de la région, sans création */
  fprintf(stdout, "[Log] Ouverture shm\n");
  fd = shm_open("monRectangle", O_RDWR, 00);
  if (fd == -1) {
    perror("Echec shm_open");
    exit(EXIT_FAILURE);}
  /* NB : pas de dimensionnement puisque pas de création */
  /* 3- Rattachement de la région */
  fprintf(stdout, "[Log] Rattachement shm\n");
  r = mmap(NULL, sizeof(Rectangle), PROT_READ|PROT_WRITE, MAP_SHARED, fd, 0);
  if (r == MAP_FAILED) {
    perror("mmap");
    exit(EXIT_FAILURE);}
  /* 4- Instanciation du rectangle */
  fprintf(stdout, "[Log] Instanciation shm\n");
  (*r).p1.x=atoi(argv[1]);
  (*r).p1.y=atoi(argv[2]);
  (*r).p2.x=atoi(argv[3]);
  (*r).p2.y=atoi(argv[4]);
  return EXIT_SUCCESS; // Fin
}
