/********************************
 * Fichier affiche-rectangle.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include "rectangle.h"

int main(int argc, char *argv[]){
  int fd; // Pour le descripteur de la zone de mémoire partagée
  Rectangle *r; // Adresse de rattachement de la mémoire

  /* 1- Ouverture de la région, sans création */
  fprintf(stdout, "[Log] Ouverture shm\n");
  fd = shm_open("monRectangle", O_RDONLY, 00);
  if (fd == -1) {
    perror("Echec shm_open");
    exit(EXIT_FAILURE);}
  /* NB : pas de dimensionnement */
  /* 2- Rattachement de la région */
  fprintf(stdout, "[Log] Rattachement shm\n");
  r = mmap(NULL, sizeof(Rectangle), PROT_READ, MAP_SHARED, fd, 0);
  if (r == MAP_FAILED) {
    perror("mmap");
    exit(EXIT_FAILURE);}
  /* 4- Instanciation du rectangle */
  fprintf(stdout, "Rectangle:(%d,%d)(%d,%d)\n",(*r).p1.x,(*r).p1.y,(*r).p2.x,(*r).p2.y);
  return EXIT_SUCCESS; // Fin
}
