/********************************
 * Fichier shm-ecrivain-sem.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include <semaphore.h>

int main(int argc, char *argv[]){
  int fd, i, valRetour;
  int *compteur;
  sem_t *semlock;

  /* RAZ de la zone de mémoire si elle existait déjà */
  valRetour = shm_unlink("/memoire");
  if (valRetour == 0) {fprintf(stdout, "RAZ du segment /memoire\n");}
  /* RAZ du semaphore s'il existe déjà */
  valRetour = sem_unlink("/memoire");
  if (valRetour == 0) {fprintf(stdout, "RAZ du semaphore /memoire\n");}
  /* Creation et ouverture memoire partagee */
  fd = shm_open("/memoire", O_RDWR | O_CREAT, 0644);
  if (fd == -1) {perror(argv[1]);exit(EXIT_FAILURE);}
  /* Dimensionnement région mémoire partagée */
  valRetour = ftruncate(fd, sizeof(int));
  if (valRetour==-1) { perror("ftruncate");exit(EXIT_FAILURE);}
  /* Creation et ouverture  memoire partagée */
  compteur = mmap(NULL,sizeof(int),PROT_WRITE,MAP_SHARED,fd,0);
  if (compteur == MAP_FAILED) {perror("mmap");exit(EXIT_FAILURE);}
  /* Ouverture (creation si n'existe pas) du sémaphore */
  semlock = sem_open("/memoire", O_CREAT, 0644, 1);
  if (semlock == SEM_FAILED) {
    perror("sem_open /memoire ecrivain");
    exit(EXIT_FAILURE);
  }
  
  for (i = 0; i < 10; i++) {
    sem_wait(semlock);	// Demande du semaphore semlock
    *compteur = i;
    fprintf(stdout, "Producteur : insertion de %d faite dans le segment partage\n",
	    (*compteur));
    sem_post(semlock);	// Relâchement du semaphore semlock
    sleep(2);
  } // fin for

  // sem_unlink("/memoire");
  exit(EXIT_SUCCESS);
}
