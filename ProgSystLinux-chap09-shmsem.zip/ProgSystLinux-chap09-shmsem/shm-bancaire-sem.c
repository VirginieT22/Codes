/********************************
 * Fichier shm-bancaire-sem.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <semaphore.h>

int main (int argc, char * argv[]){
  int   fd1, fd2; // descripteurs de région de memoire partagée
  int * cpt1, * cpt2; // var. de rattachement des regions 
  int somme; // resultat de la somme des deux comtes
  pid_t pid_fils; // PID du processus fils
  int val_retour; // stockage de valeur de retour d'appel de primitive
  sem_t * semlock1, * semlock2;

  // Suppression des regions pour RAZ
  shm_unlink("cpt1"); shm_unlink("cpt2"); 
  
  // Region de memoire cpt1 : creation, ouverture, dimensionn.
  fd1 = shm_open("cpt1", O_RDWR|O_CREAT, 0600); 
  if (fd1 == -1) { perror("cpt1"); exit(EXIT_FAILURE);}
  val_retour = ftruncate(fd1, sizeof(int)); 
  if (val_retour == -1) { perror("ftruncate fd1"); exit(EXIT_FAILURE);}
  // Region de memoire cpt2 : creation, ouverture, dimensionn.
  fd2 = shm_open("cpt2", O_RDWR|O_CREAT, 0600); 
  if (fd2 == -1) { perror("cpt2"); exit(EXIT_FAILURE);}
  val_retour = ftruncate(fd2, sizeof(int));
  if (val_retour == -1) { perror("ftruncate fd2"); exit(EXIT_FAILURE);}
  // Rattachement des regions a l'espace d'adressage
  cpt1 = mmap(NULL, sizeof(int), PROT_READ | PROT_WRITE, MAP_SHARED, fd1, 0);
  if (cpt1==MAP_FAILED){perror("mmap cpt1"); return EXIT_FAILURE;}
  cpt2 = mmap(NULL, sizeof(int), PROT_READ | PROT_WRITE, MAP_SHARED, fd2, 0);
  if (cpt2==MAP_FAILED){perror("mmap cpt2"); return EXIT_FAILURE;}

  // Instanciation du contenu des comptes
  * cpt1 = 200; fprintf(stdout, "Solde du compte 1  : %d\n", *cpt1);
  * cpt2 = 100; fprintf(stdout, "Solde du compte 2  : %d\n", *cpt2);

  // CREATION ET OUVERTURE DE SEMAPHORES
  semlock1 = sem_open("lock_cpt1", O_CREAT, 0644, 1); // 1 jeton (MUTEX)
  if (semlock1 ==SEM_FAILED){
    perror("sem_open lock_cpt1");
    exit(EXIT_FAILURE);}
  semlock2 = sem_open("lock_cpt2", O_CREAT, 0644, 1); // 1 jeton (MUTEX)
  if (semlock2 == SEM_FAILED){
    perror("sem_open lock_cpt2");
    exit(EXIT_FAILURE);}
 
  // Creation d'un processus fils
  pid_fils = fork();
  
  if (pid_fils==0){ // Code du fils : calcul de la somme des comptes
    int * premier_cpt, * second_cpt; // Var rattach. spécifiques fils
    // Rattachement des regions
    premier_cpt = mmap(NULL, sizeof(int), PROT_READ|PROT_WRITE, MAP_SHARED, fd1, 0);
    if (premier_cpt==MAP_FAILED) {perror("mmap premier_cpt"); exit(EXIT_FAILURE);}
    second_cpt = mmap(NULL, sizeof(int), PROT_READ|PROT_WRITE, MAP_SHARED, fd2, 0);
    if (second_cpt==MAP_FAILED) {perror("mmap second_cpt"); exit(EXIT_FAILURE);}
    // Calcul de la somme des deux comptes
    sleep(1); // Simulation du temps de lancement du fils
    sem_wait(semlock1); // DEMANDE SEMAPHORE semlock1
    sem_wait(semlock2); // DEMANDE SEMAPHORE semlock2
    somme = * premier_cpt + * second_cpt; // Calcul somme cpts
    sem_post(semlock1); // RELACHE SEMAPHORE semlock1
    sem_post(semlock2); // RELACHE SEMAPHORE semlock2
    fprintf(stdout, "(Fils) La somme des comptes est : %d\n",somme);
    exit(EXIT_SUCCESS);
  }

  // Code associé au pere : transfert de 50 euros de cpt1 vers cpt2	  
  fprintf(stdout, "(Pere) Debut virement : Debit 50 euros de cpt1\n");
  sem_wait(semlock1); // DEMANDE SEMAPHORE semlock1
  sem_wait(semlock2); // DEMANDE SEMAPHORE semlock2
  * cpt1 = 200-50;
  sleep(3); // Simulation d'un temps de réponse du SI bancaire
  * cpt2 = 100+50;
  sem_post(semlock1); // RELACHE SEMAPHORE semlock1
  sem_post(semlock2); // RELACHE SEMAPHORE semlock2
  fprintf(stdout, "(Pere) Fin virement : Credit 50 euros sur cpt2\n");
  sleep(3); // Simulation d'un temps de réponse du SI bancaire
  fprintf(stdout, "(Pere) Fin \n");

  wait(NULL); // Attente du fils pour eviter orphelin
  shm_unlink("cpt1"); shm_unlink("cpt2"); // Suppression région
  return EXIT_SUCCESS;
}
