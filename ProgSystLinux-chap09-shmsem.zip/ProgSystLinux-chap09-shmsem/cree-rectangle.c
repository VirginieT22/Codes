/********************************
 * Fichier cree-rectangle.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include "rectangle.h"

int main(){
  int fd; // Pour le descripteur de la zone de mémoire partagée
  int returnValue; // Pour valeur retour ftruncate

  /* 1- Création de la région */
  fprintf(stdout, "[Log] Création shm\n");
  fd = shm_open("monRectangle", O_RDWR | O_CREAT , 0666);
  if (fd == -1) {
    perror("Echec shm_open\n");
    exit(EXIT_FAILURE);}
  /* 2- Dimensionnement de la région */
  fprintf(stdout, "[Log] Dimensionnement shm\n");
  returnValue = ftruncate(fd, sizeof(Rectangle));
  if (returnValue == -1) {
    perror("Echec ftruncate");
    exit(EXIT_FAILURE);}
  return EXIT_SUCCESS;
}
