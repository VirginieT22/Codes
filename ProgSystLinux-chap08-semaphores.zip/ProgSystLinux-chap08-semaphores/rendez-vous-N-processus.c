/********************************
 * Fichier rendez-vous-N-processus.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/

/* Includes pour exit */
#include <stdlib.h>

/* Includes pour perror/printf */
#include <stdio.h>

/* Includes pour les processus */
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

/* Includes pour les semaphores */
#include <fcntl.h>              /* Pour les constantes de type O_* */
#include <semaphore.h>

#define N 10
#define NOM_SEMAPHORE_BASE "/sem"
#define TAILLE_NOM 10

void processus(int i, sem_t *sems[], unsigned int temps_attente)
{
  char nom_sem[TAILLE_NOM];
  int j, k;
  int status;

  sleep(temps_attente);

  /* avant le point de rendez-vous */
  printf("je suis le processus %d (%d), j'ai attendu %ds, et je suis au point de rendez-vous\n",
         getpid(), getpid(), i);

  for (j = 0; j < N; j++) {
    if (j != i) {
      status = sem_post(sems[j]);
      if (status != 0) {
        perror("Rendu du jeton");
        for (k = 0; k < N; k++) {
          sprintf(nom_sem, "%s%d", NOM_SEMAPHORE_BASE, k);
          sem_unlink(nom_sem);
        }
        exit(EXIT_FAILURE);
      }
    }
  }

  for (j = 0; j < N; j++) {
    if (j != i) {
      status = sem_wait(sems[i]);
      if (status != 0) {
        perror("Prise du jeton");
        for (k = 0; k < N; k++) {
          sprintf(nom_sem, "%s%d", NOM_SEMAPHORE_BASE, k);
          sem_unlink(nom_sem);
        }
        exit(EXIT_FAILURE);
      }
    }
  }

  sleep(1);
  printf("je suis le processus %d (%d), et je pars du point de rendez-vous\n",
         getpid(), i);

}

int main()
{
  pid_t pids[N];
  sem_t *sems[N];
  char nom_sem[TAILLE_NOM];
  int i, j, k;
  unsigned int temps_attente;

  /* les indices des processus pour le tableau de semaphore seront :
   * Pere = 0
   * Fils 1 = 1
   * ...
   * Fils N-1 = N-1
   */

  /* Création et initialisation des sémaphores */
  for (i = 0; i < N; i++) {
    sprintf(nom_sem, "%s%d", NOM_SEMAPHORE_BASE, i);
    sems[i] = sem_open(nom_sem, O_CREAT, 0644, 0);
    if (sems[i] == SEM_FAILED) {
      perror("Impossible de créer le semaphore");
      return EXIT_FAILURE;
    }
  }

  /* Initialisation graine pour la génération de nombre aléatoire pour le "sleep" */
  srand(0);

  for (i = 1; i < N; i++) {
    /* Générer l'attente aléatoire */
    temps_attente = (unsigned int)(rand()) % 10;

    pids[i] = fork();
    if (pids[i] == 0) {         /* code du fils i */

      /* Déroulement du processus fils */
      processus(i, sems, temps_attente);

      /* On doit quitter le processus fils */
      exit(EXIT_SUCCESS);
    }

    /* Erreur */
    else if (pids[i] < 0) {
      perror("Impossible de créer un processus");
      for (k = 0; k < N; k++) {
        sprintf(nom_sem, "%s%d", NOM_SEMAPHORE_BASE, k);
        sem_unlink(nom_sem);
      }
      return EXIT_FAILURE;
    }
  }

  /* Générer l'attente aléatoire */
  temps_attente = (unsigned int)(rand()) % 10;

  /* Déroulement du processus */
  processus(0, sems, temps_attente);

  /* Attendre la fin de chaque processus fils */
  for (j = 1; j < N; j++) {
    waitpid(pids[j], NULL, -1);
  }

  /* Libérer les sémaphores */
  for (j = 0; j < N; j++) {
    sprintf(nom_sem, "%s%d", NOM_SEMAPHORE_BASE, j);
    sem_unlink(nom_sem);
  }

  return EXIT_SUCCESS;
}
