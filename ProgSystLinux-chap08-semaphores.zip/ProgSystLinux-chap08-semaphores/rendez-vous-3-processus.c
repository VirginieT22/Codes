/********************************
 * Fichier rendez-vous-3-processus.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/

/* Includes pour exit */
#include <stdlib.h>

/* Includes pour perror/printf */
#include <stdio.h>

/* Includes pour les processus */
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

/* Includes pour les semaphores */
#include <fcntl.h>              /* Pour les constantes de type O_* */
#include <semaphore.h>

#define NOM_SEM_PERE "/sem_pere"
#define NOM_SEM_FILS1 "/sem_fils1"
#define NOM_SEM_FILS2 "/sem_fils2"

int main(){
  pid_t fils1, fils2;
  sem_t *sem_pere, *sem_fils1, *sem_fils2;
  int status;

  /* Création et initialisation des sémaphores */
  sem_pere = sem_open(NOM_SEM_PERE, O_CREAT, 0644, 0);
  if (sem_pere == SEM_FAILED) {
    perror("Impossible de créer le semaphore");
    return EXIT_FAILURE;
  }
  sem_fils1 = sem_open(NOM_SEM_FILS1, O_CREAT, 0644, 0);
  if (sem_fils1 == SEM_FAILED) {
    perror("Impossible de créer le semaphore");
    return EXIT_FAILURE;
  }
  sem_fils2 = sem_open(NOM_SEM_FILS2, O_CREAT, 0644, 0);
  if (sem_fils2 == SEM_FAILED) {
    perror("Impossible de créer le semaphore");
    return EXIT_FAILURE;
  }

  fils1 = fork();
  if (fils1 == 0) { /* code du fils 1 */
    sleep(5); /* Attente pour simuler une désynchronization */

    /* avant le point de rendez-vous */
    printf("je suis %d, et je suis au point de rendez-vous\n", getpid());
    /* le fils 1 informe ses voisins de son arrivee au rendez-vous */
    status = sem_post(sem_pere);
    if (status != 0) {
      perror("Rendu du jeton 0");
      sem_unlink(NOM_SEM_PERE);
      sem_unlink(NOM_SEM_FILS1);
      sem_unlink(NOM_SEM_FILS2);
      exit(EXIT_FAILURE);
    }
    status = sem_post(sem_fils2);
    if (status != 0) {
      perror("Rendu du jeton 0");
      sem_unlink(NOM_SEM_PERE);
      sem_unlink(NOM_SEM_FILS1);
      sem_unlink(NOM_SEM_FILS2);
      exit(EXIT_FAILURE);
    }
    status = sem_wait(sem_fils1);
    if (status != 0) {
      perror("Prise du jeton 1");
      sem_unlink(NOM_SEM_PERE);
      sem_unlink(NOM_SEM_FILS1);
      sem_unlink(NOM_SEM_FILS2);
      exit(EXIT_FAILURE);
    }
    status = sem_wait(sem_fils1);
    if (status != 0) {
      perror("Prise du jeton 1");
      sem_unlink(NOM_SEM_PERE);
      sem_unlink(NOM_SEM_FILS1);
      sem_unlink(NOM_SEM_FILS2);
      exit(EXIT_FAILURE);
    }
    sleep(1);
    printf("je suis %d, et je pars du point de rendez-vous\n", getpid());
    /* apres le point de rendez-vous */
    exit(EXIT_SUCCESS);
  }

  /* code du pere */
  else if (fils1 > 0) {
    fils2 = fork();
    if (fils2 == 0) {  /* code du fils 2 */
      sleep(10); /* Attente pour simuler une désynchronization */
      /* avant le point de rendez-vous */
      printf("je suis %d, et je suis au point de rendez-vous\n",getpid());
      /* le fils 2 informe ses voisins de son arrivee au rendez-vous */
      status = sem_post(sem_pere);
      if (status != 0) {
        perror("Rendu du jeton 0");
        sem_unlink(NOM_SEM_PERE);
        sem_unlink(NOM_SEM_FILS1);
        sem_unlink(NOM_SEM_FILS2);
        exit(EXIT_FAILURE);
      }
      status = sem_post(sem_fils1);
      if (status != 0) {
        perror("Rendu du jeton 1");
        sem_unlink(NOM_SEM_PERE);
        sem_unlink(NOM_SEM_FILS1);
        sem_unlink(NOM_SEM_FILS2);
        exit(EXIT_FAILURE);
      }
      status = sem_wait(sem_fils2);
      if (status != 0) {
        perror("Prise du jeton 2");
        sem_unlink(NOM_SEM_PERE);
        sem_unlink(NOM_SEM_FILS1);
        sem_unlink(NOM_SEM_FILS2);
        exit(EXIT_FAILURE);
      }
      status = sem_wait(sem_fils2);
      if (status != 0) {
        perror("Prise du jeton 2");
        sem_unlink(NOM_SEM_PERE);
        sem_unlink(NOM_SEM_FILS1);
        sem_unlink(NOM_SEM_FILS2);
        exit(EXIT_FAILURE);
      }
      sleep(1);
      printf("je suis %d, et je pars du point de rendez-vous\n", getpid());
      /* apres le point de rendez-vous */
      exit(EXIT_SUCCESS);
    }

    /* code du pere */
    else if (fils2 > 0) {
      /* avant le point de rendez-vous */
      printf("je suis %d, et je suis au point de rendez-vous\n", getpid());
      status = sem_post(sem_fils1);
      if (status != 0) {
        perror("Rendu du jeton 1");
        sem_unlink(NOM_SEM_PERE);
        sem_unlink(NOM_SEM_FILS1);
        sem_unlink(NOM_SEM_FILS2);
        exit(EXIT_FAILURE);
      }
      status = sem_post(sem_fils2);
      if (status != 0) {
        perror("Rendu du jeton 2");
        sem_unlink(NOM_SEM_PERE);
        sem_unlink(NOM_SEM_FILS1);
        sem_unlink(NOM_SEM_FILS2);
        exit(EXIT_FAILURE);
      }
      status = sem_wait(sem_pere);
      if (status != 0) {
        perror("Prise du jeton 0");
        sem_unlink(NOM_SEM_PERE);
        sem_unlink(NOM_SEM_FILS1);
        sem_unlink(NOM_SEM_FILS2);
        exit(EXIT_FAILURE);
      }
      status = sem_wait(sem_pere);
      if (status != 0) {
        perror("Prise du jeton 0");
        sem_unlink(NOM_SEM_PERE);
        sem_unlink(NOM_SEM_FILS1);
        sem_unlink(NOM_SEM_FILS2);
        exit(EXIT_FAILURE);
      }
      sleep(1);
      printf("je suis %d, et je pars du point de rendez-vous\n", getpid());
      /* apres le point de rendez-vous */
    }

    /* Erreur */
    else {
      perror("Impossible de créer un processus (fils 2");
      sem_unlink(NOM_SEM_PERE);
      sem_unlink(NOM_SEM_FILS1);
      sem_unlink(NOM_SEM_FILS2);
      return EXIT_FAILURE;
    }
  }

  /* Erreur */
  else {
    perror("Impossible de créer un processus (fils 1");
    sem_unlink(NOM_SEM_PERE);
    sem_unlink(NOM_SEM_FILS1);
    sem_unlink(NOM_SEM_FILS2);
    return EXIT_FAILURE;
  }

  /* Attente processus fils */
  waitpid(fils1, NULL, -1);
  waitpid(fils2, NULL, -1);

  /* Liberation des sémaphores */
  sem_unlink(NOM_SEM_PERE);
  sem_unlink(NOM_SEM_FILS1);
  sem_unlink(NOM_SEM_FILS2);

  return EXIT_SUCCESS;
}
