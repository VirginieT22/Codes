/********************************
 * Fichier rendez-vous-2-nomme.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/

/* Includes pour exit */
#include <stdlib.h>

/* Includes pour perror/printf */
#include <stdio.h>

/* Includes pour les processus */
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

/* Includes pour les semaphores */
#include <fcntl.h>              /* Pour les constantes de type O_* */
#include <semaphore.h>


int main(int argc, char *argv[])
{
    sem_t *sem_courant;
    sem_t *sem_autre;
    int status;

    /* Check arguments */
    if (argc != 3) {
      printf("%s <nom_semaphore_processus_courant> <nom_semaphore_autre_processus>\n", argv[0]);
      return EXIT_FAILURE;
    }

    /* Création et initialisation du sémaphore du processus */
    sem_courant = sem_open(argv[1], O_CREAT, 0644, 0);
    if (sem_courant == SEM_FAILED) {
        perror("Impossible de créer le semaphore courant");
        return EXIT_FAILURE;
    }

    /* Atente pour avoir le temps de lancer l'autre programme */
    sleep(4);

    /* Accès au sémaphore de l'autre processus */
    sem_autre = sem_open(argv[2], 0, 0644, 0);
    if (sem_autre == SEM_FAILED) {
        perror("Impossible d'acceder au semaphore de l'autre processus");
        return EXIT_FAILURE;
    }

    /* avant le point de rendez-vous */
    printf("je suis le processus %d, et je suis au point de rendez-vous\n",
           getpid());

    /* Rendu du jeton au processus père */
    status = sem_post(sem_courant);
    if (status != 0) {
      perror("Rendu du jeton courant");
      sem_unlink(argv[1]);
      exit(EXIT_FAILURE);
    }

    /* Prise du jeton du processus autre */
    status = sem_wait(sem_autre);
    if (status != 0) {
      perror("Prise du jeton de l'autre processus autre");
      sem_unlink(argv[1]);
      exit(EXIT_FAILURE);
    }

    sleep(1);
    printf("je suis le processus %d, et je pars du point de rendez-vous\n",
           getpid());

    sem_unlink(argv[1]);

    return EXIT_SUCCESS;
}
