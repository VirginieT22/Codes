/********************************
 * Fichier exemple.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/

/* Includes pour exit */
#include <stdlib.h>

/* Includes pour perror/printf */
#include <stdio.h>

/* Includes pour les processus */
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

/* Includes pour les semaphores */
#include <fcntl.h>              /* Pour les constantes de type O_* */
#include <semaphore.h>

/* Déclaration d'une constante pour un nombre d'étapes */
#define N 10
#define NOM_SEMAPHORE "/sem"

/**
 *  Déroulement d'une itération. Cette fonction permet d'isoler le coeur de l'utilisation des
 *  sémaphores sans polluer a logique par la gestion des processus.
 *
 *  @param pid le pid du processus
 *  @param semaphore le semaphore
 */
void iteration(pid_t pid, sem_t * semaphore, const char *tag)
{
  int status;
  int i;

  /* Message de debug pour valider que le processus est prêt */
  printf("%s[%d] prêt!\n", tag, pid);

  for (i = 0; i < N; i++) {
    /* Demande du jeton */
    status = sem_wait(semaphore);
    if (status != 0) {
      perror("Prise du jeton");
      exit(EXIT_FAILURE);
    }

    /* Section critique */
    printf("%s[%d] (%d) - j'entre en section critique\n", tag, pid, i);
    sleep(1);
    printf("%s[%d] (%d) - je sors de la section critique\n", tag, pid, i);

    /* Restitution du jeton */
    status = sem_post(semaphore);
    if (status != 0) {
      perror("Rendu du jeton");
      exit(EXIT_FAILURE);
    }
  }
}

int main()
{
  /* Déclarations des variables */
  pid_t pid;
  sem_t *semaphore; /* Pour stocker le descripteur du sémaphore */

  /* Création et initialisation du sémaphore */
  semaphore = sem_open(NOM_SEMAPHORE, O_CREAT | O_EXCL, 0644, 1);
  if (semaphore == SEM_FAILED) {
    perror("Impossible de créer le semaphore");
    return EXIT_FAILURE;
  }
  printf("Sémaphore créé dans /dev/shm/sem.%s\n", &NOM_SEMAPHORE[1]);

  /* Déroulement */
  pid = fork();
  if (pid == 0) {             /* Fils */
    iteration(getpid(), semaphore, "fils");

    /* On indique que le semaphore ne nous est plus utile */
    sem_close(semaphore);
    printf("Le fils a indiqué qu'il n'a plus besoin du sémaphore\n");

  } else if (pid > 0) {       /* Père */
    iteration(getpid(), semaphore, "père");

    /* On attend le fils ! */
    waitpid(pid, NULL, 0);

    /* On indique que le semaphore ne nous est plus utile */
    sem_close(semaphore);
    printf("Le père a indiqué qu'il n'a plus besoin du sémaphore\n");
  } else {                    /* Erreur */
    perror("Impossible de créer un processus");
    sem_unlink(NOM_SEMAPHORE);
    return EXIT_FAILURE;
  }

  /* Liberation du semaphore */
  sem_unlink(NOM_SEMAPHORE);

  /* Fin de programme */
  return EXIT_SUCCESS;
}
