/********************************
 * Fichier rendez-vous-2-processus.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/

/* Includes pour exit */
#include <stdlib.h>

/* Includes pour perror/printf */
#include <stdio.h>

/* Includes pour les processus */
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

/* Includes pour les semaphores */
#include <fcntl.h>              /* Pour les constantes de type O_* */
#include <semaphore.h>

/* Déclaration des constantes pour les noms des sémaphores */
#define NOM_SEMAPHORE_pere "/pere"
#define NOM_SEMAPHORE_fils "/fils"

int main(){
  pid_t pid; /* Pour stocker le pid du fils */
  sem_t *sem_pere; /* Pour stocker le descripteur du semaphore "père" */
  sem_t *sem_fils; /* Pour stocker le descripteur du semaphore "fils" */
  int status; /* Pour stocker les valeurs de retour des wait et post */

  /* Création et initialisation des sémaphores */
  sem_pere = sem_open(NOM_SEMAPHORE_pere, O_CREAT, 0644, 0);
  if (sem_pere == SEM_FAILED) {
    perror("Impossible de créer le semaphore pere");
    return EXIT_FAILURE;
  }
  sem_fils = sem_open(NOM_SEMAPHORE_fils, O_CREAT, 0644, 0);
  if (sem_fils == SEM_FAILED) {
    perror("Impossible de créer le semaphore fils");
    return EXIT_FAILURE;
  }

  pid = fork();
  if (pid == 0) { /* Code associé au processus fils */
    sleep(5); /* Attente pour introduire une désynchronisation */

    /* avant le point de rendez-vous */
    printf("je suis %d, et je suis au point de rendez-vous\n", getpid());

    status = sem_post(sem_pere); /* Rendu du jeton au processus père */
    if (status != 0) {
      perror("Rendu du jeton pere");
      sem_unlink(NOM_SEMAPHORE_pere);
      sem_unlink(NOM_SEMAPHORE_fils);
      exit(EXIT_FAILURE);
    }

    status = sem_wait(sem_fils); /* Prise du jeton du processus fils */
    if (status != 0) {
      perror("Prise du jeton fils");
      sem_unlink(NOM_SEMAPHORE_pere);
      sem_unlink(NOM_SEMAPHORE_fils);
      exit(EXIT_FAILURE);
    }
    sleep(1); // Attente de 1 seconde
    printf("je suis %d, et je pars du point de rendez-vous\n", getpid());
    /* apres le point de rendez-vous */
    exit(EXIT_SUCCESS);
  }

  else if (pid > 0) { /* Code associé au processus père */
    /* avant le point de rendez-vous */
    printf("je suis le processus %d, et je suis au point de rendez-vous\n", getpid());

    status = sem_wait(sem_pere); /* Prise du jeton du père */
    if (status != 0) {
      perror("Prise du jeton pere");
      sem_unlink(NOM_SEMAPHORE_pere);
      sem_unlink(NOM_SEMAPHORE_fils);
      exit(EXIT_FAILURE);
    }

    status = sem_post(sem_fils); /* Rendu du jeton au fils */
    if (status != 0) {
      perror("Rendu du jeton fils");
      sem_unlink(NOM_SEMAPHORE_pere);
      sem_unlink(NOM_SEMAPHORE_fils);
      exit(EXIT_FAILURE);
    }

    sleep(1); /* Attente de 1 seconde */

    printf("je suis le processus %d, et je pars du point de rendez-vous\n",getpid());

    /* apres le point de rendez-vous */
  }

  /* Si erreur de création de processus fils */
  else {
    perror("Impossible de créer un processus");
    sem_unlink(NOM_SEMAPHORE_pere);
    sem_unlink(NOM_SEMAPHORE_fils);
    return EXIT_FAILURE;
  }

  /* Attente du processus fils */
  waitpid(pid, NULL, -1);

  /* Liberation des sémaphores */
  sem_unlink(NOM_SEMAPHORE_pere);
  sem_unlink(NOM_SEMAPHORE_fils);

  return EXIT_SUCCESS;
}
