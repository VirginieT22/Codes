/********************************
 * Fichier rendez-vous-2-processus-alternance.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/

/* Includes pour exit */
#include <stdlib.h>

/* Includes pour perror/printf */
#include <stdio.h>

/* Includes pour les processus */
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

/* Includes pour les semaphores */
#include <fcntl.h>              /* Pour les constantes de type O_* */
#include <semaphore.h>

#define N 10
#define NOM_SEMAPHORE_PAIR "/sem0"
#define NOM_SEMAPHORE_IMPAIR "/sem1"

int main()
{
    pid_t pid;
    sem_t *sem_pair;
    sem_t *sem_impair;
    int i, status;

    /* Création et initialisation des sémaphores */
    sem_pair = sem_open(NOM_SEMAPHORE_PAIR, O_CREAT, 0644, 0);
    if (sem_pair == SEM_FAILED) {
        perror("Impossible de créer le semaphore");
        return EXIT_FAILURE;
    }

    sem_impair = sem_open(NOM_SEMAPHORE_IMPAIR, O_CREAT, 0644, 0);
    if (sem_impair == SEM_FAILED) {
        perror("Impossible de créer le semaphore");
        return EXIT_FAILURE;
    }

    /* Création du processus fils */
    printf("Proc_impair\tProc_pair\n");
    pid = fork();

    /* code du fils, boucle des impairs, devra commencer en premier */
    if (pid == 0) {
        for (i = 0; i < N; i++) {
            /* Affichage du nombre impair */
            sleep(1);
            printf("%d\n", 2 * i + 1);

            /* Rendu du jeton impair */
            status = sem_post(sem_pair);
            if (status != 0) {
                perror("Rendu du jeton pair");
                sem_unlink(NOM_SEMAPHORE_PAIR);
                sem_unlink(NOM_SEMAPHORE_IMPAIR);
                exit(EXIT_FAILURE);
            }

            /* Prise du jeton impair */
            status = sem_wait(sem_impair);
            if (status != 0) {
                perror("Prise du jeton impair");
                sem_unlink(NOM_SEMAPHORE_PAIR);
                sem_unlink(NOM_SEMAPHORE_IMPAIR);
                exit(EXIT_FAILURE);
            }
        }

        exit(EXIT_SUCCESS);
    }

    /* code du pere, boucle des pairs, doit attendre le signal de son fils */
    else if (pid > 0) {
        for (i = 0; i < N; i++) {
            /* Prise du jeton pair */
            status = sem_wait(sem_pair);
            if (status != 0) {
                perror("Prise du jeton pair");
                sem_unlink(NOM_SEMAPHORE_PAIR);
                sem_unlink(NOM_SEMAPHORE_IMPAIR);
                exit(EXIT_FAILURE);
            }

            /* Affichage du nombre pair */
            sleep(1);
            printf("\t%d\n", 2 * i + 2);

            /* Rendu du jeton impair */
            status = sem_post(sem_impair);
            if (status != 0) {
                perror("Rendu du jeton impair");
                sem_unlink(NOM_SEMAPHORE_PAIR);
                sem_unlink(NOM_SEMAPHORE_IMPAIR);
                exit(EXIT_FAILURE);
            }
        }
    }

    /* Erreur */
    else {
        perror("Impossible de créer un processus");
        sem_unlink(NOM_SEMAPHORE_PAIR);
        sem_unlink(NOM_SEMAPHORE_IMPAIR);
        return EXIT_FAILURE;
    }

    /* Attente du processus fils */
    waitpid(pid, NULL, -1);

    /* Liberation des sémaphores */
    sem_unlink(NOM_SEMAPHORE_PAIR);
    sem_unlink(NOM_SEMAPHORE_IMPAIR);

    return EXIT_SUCCESS;
}
