/********************************
 * Fichier famille2_v2.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h>		/* stderr, stdout, fprintf */
#include <unistd.h>		/* fork */
#include <sys/wait.h>		/* wait */
#include <stdlib.h>		/* exit */

int main(void)
{
	pid_t pid_fils = -1;
	pid_t wait_return_value = -1;
	int pid_de_p1 = getpid();	/* Cette variable contient le PID de p1 */
	int i = 0;

	printf("(PID : %d, PPID : %d) p1- Bonjour\n", getpid(), getppid());

	for (i = 0; i < 4; i++) {	/* 4 fois.. */
		if (getpid() == pid_de_p1) {	/* Code exécuté par p1 seulement car fork dans iteration */
			pid_fils = fork();	/* Créer un fils */
			if (pid_fils != 0) {	/* Code père */
				printf("(PID : %d) Création de %d\n", getpid(), pid_fils);
			} else {	/* Code fils pid_fils */
				printf("(PID : %d, PPID : %d) Bonjour, au revoir\n",getpid(),getppid());
				exit(EXIT_SUCCESS);	/* Fin du code associé au processus */
			}
		}
	}

	/* Code exécuté par p1 seulement */
	for (i = 0; i < 4; i++) {
		wait_return_value = wait(NULL);
		printf("(PID : %d) débloqué par %d \n", getpid(), wait_return_value);
	}
	printf("(PID : %d) Au revoir. \n", getpid());
	exit(EXIT_SUCCESS);
}
