/********************************
 * Fichier famille1_rec.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h>		/* stderr, stdout, fprintf */
#include <unistd.h>		/* fork */
#include <sys/wait.h>		/* wait */
#include <stdlib.h>		/* exit */

void cree_fils(int n){
  pid_t pid_fils;
  if (n==0) {printf("Fini !\n");}
  else {
    printf("Creation fils %d\n",n);
    pid_fils=fork();
    if (pid_fils==-1){perror("fork"); exit(EXIT_FAILURE);};
    if (pid_fils!=0){
      // Pere
      sleep(1);
      printf("Attente fils %d\n",n);
      wait(NULL);}
    else {
      // Fils
      cree_fils(n-1);
      sleep(1);}
  }
}

int main(void){
  int nb_fils=3;
  cree_fils(nb_fils);
  exit(EXIT_SUCCESS);
}
