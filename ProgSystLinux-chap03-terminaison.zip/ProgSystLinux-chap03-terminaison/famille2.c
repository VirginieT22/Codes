/********************************
 * Fichier famille2.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h>		/* stderr, stdout, fprintf */
#include <unistd.h>		/* fork */
#include <sys/wait.h>		/* wait */
#include <stdlib.h>		/* exit */

void code_duplique_pere_fils(pid_t pid_fils)
{
	if (pid_fils != 0) {	/* Code père */
		printf("(PID : %d) Création de %d\n", getpid(), pid_fils);
	} else {		/* Code fils pid_fils */
		printf("(PID : %d, PPID : %d) Bonjour, au revoir\n", getpid(), getppid());
		exit(EXIT_SUCCESS);	/* Fin du code associé au processus fils */
	}
}

int main(void)
{
	pid_t pid_fils1 = -1, pid_fils2 = -1, pid_fils3 = -1, pid_fils4 = -1;
	pid_t wait_return_value = -1;
	int i = 0;

	printf("(PID : %d, PPID : %d) p1- Bonjour\n", getpid(), getppid());
	pid_fils1 = fork();	/* Créer un fils (p2) */
	code_duplique_pere_fils(pid_fils1);
	pid_fils2 = fork();	/* Créer un autre fils (p3) */
	code_duplique_pere_fils(pid_fils2);
	pid_fils3 = fork();	/* Créer encore un fils (p4) */
	code_duplique_pere_fils(pid_fils3);
	pid_fils4 = fork();	/* Et encore un (p5) */
	code_duplique_pere_fils(pid_fils4);
	/* Code exécuté par p1 seulement */
	for (i = 0; i < 4; i++) {
		wait_return_value = wait(NULL);
		printf("(PID : %d) débloqué par %d \n", getpid(), wait_return_value);
	}
	printf("(PID : %d) Au revoir. \n", getpid());
	exit(EXIT_SUCCESS);
}
