/********************************
 * Fichier client-pipe-sol.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h> // printf, perror
#include <stdlib.h> // EXIT_SUCCESS
#include <fcntl.h> // open, O_WRONLY et O_RONLY
#include <unistd.h> // read, write, close, 
#include <sys/types.h> // mkfifo
#include <sys/stat.h> // mkfifo

// PROCESSUS CLIENT

int main(void){
  int tubeOut; // Descripteur tube pour données sortantes
  int tubeIn; // Descripteur tube pour données entrantes
  int nb1, nb2, res; // Nombres et résultat

  /* 1- RECUPERATION ENTIERS ET ENVOI AU SERVEUR */
  /* Demande d'entree de l'utilisateur */
  printf("(client) Entrez les deux nombres a additionner\n");
  scanf("%d %d", &nb1, &nb2);

  /* Ouverture du tube client vers serveur en ecriture */
  tubeOut = open("tubeClientVersServeur", O_WRONLY);
  if (tubeOut == -1){
    perror ("(client) Ouverture du tube client vers serveur impossible ");
    exit(EXIT_FAILURE);
  }

  /* Envoi des donnees au serveur dans le tube client vers serveur */
  write(tubeOut, &nb1, sizeof(int));
  write(tubeOut, &nb2, sizeof(int));
  close(tubeOut);

  /* 2- RECUPERATION DU RESULTAT DU SERVEUR */
  /* Ouverture du tube serveur vers client en lecture */
  tubeIn = open("tubeServeurVersClient", O_RDONLY);
  if (tubeIn == -1){
    perror ("(client) Ouverture du tube serveur vers client impossible ");
    exit(EXIT_FAILURE);
  }
  /* Lecture du resultat dans le tube serveur vers client */
  read(tubeIn, &res, sizeof(int));
  /* Restitution a l'utilisateur */
  printf("Le resultat est : %d\n", res);
  close(tubeIn);
  
  unlink("tubeClientVersServeur"); // suppression tubes
  unlink("tubeServeurVersClient"); // suppression tubes
  exit(EXIT_SUCCESS);
}
