/********************************
 * Fichier tubeOrdi1prod1consoV2.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h>		// printf
#include <stdlib.h>		// EXIT_SUCCESS, EXIT_FAILURE
#include <unistd.h>		// fork, exit, pipe, close, write, read
#include <string.h>		// strlen
#include <sys/wait.h>		// wait

int main(void) {
  /* Déclaration de variables */
  int tube[2]; // Tube à créer
  int valRetour; // Pour valeur de retour d'appel de pipe
  char readBuffer[80]; // Pour stocker les données lues
  pid_t pid_fils; // Pour récupérer le pid du fils 

  /* Creation du tube */
  valRetour = pipe(tube);
  if (valRetour == -1) {
    perror("creation du tube impossible");
    exit(EXIT_FAILURE);
  }

  /* Création du processus fils */
  pid_fils = fork();
  if (pid_fils == -1){
    perror("creation du fils impossible");
    exit(EXIT_FAILURE);
  }

  if (pid_fils != 0) {
    /* Code affecté au processus pere */
    close(tube[0]); // Fermeture du descripteur en lecture
    /* Ecriture dans le tube */ 
    char *chapeaux = "Ils ont des chapeaux ronds, Vive la Bretagne!";
    write(tube[1], chapeaux, strlen(chapeaux)); // Ecriture
    // write(tube[1],"\0",1) // Si ajout de char de fin de chaine à l'écriture plutôt qu'à la lecture
    close(tube[1]); // Fermeture du descripteur en écriture
    wait(NULL);	/* Attente de la terminaison du processus fils */
    exit(EXIT_SUCCESS); // fin code père
  } else {
    /* Code affecté au processus fils */
    close(tube[1]); // Fermeture du descripteur en écriture
    /* Une seule lecture de toutes les données */
    ssize_t nbCharLus; 
    nbCharLus=read(tube[0], readBuffer, sizeof(readBuffer)) ;
    readBuffer[nbCharLus]='\0';
    fprintf(stdout, "%s\n", readBuffer);
    close(tube[0]); // Fermeture du descripteur en lecture
    exit(EXIT_SUCCESS); // fin code fils
  }
} // fin main
