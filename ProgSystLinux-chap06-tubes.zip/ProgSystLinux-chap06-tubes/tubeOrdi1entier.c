/********************************
 * Fichier tubeOrdi1entier.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h>		// printf, scanf
#include <stdlib.h>		// EXIT_SUCCESS, EXIT_FAILURE
#include <unistd.h>		// fork, exit, pipe, close, write, read
#include <sys/wait.h>		// wait

int main(void){
  /* Declaration de variables */
  int tube[2]; // Tube à créer
  int valRetour; // Pour valeur de retour d'appel de pipe
  pid_t pid_fils; // Pour récupérer le pid du fils
  int entier = 0; // Variable entière

  /* Creation du tube */
  valRetour=pipe(tube);
  if (valRetour == -1) {
    perror("creation du tube impossible");
    exit(EXIT_FAILURE);
  }

   /* Creation du fils */
  pid_fils = fork();
  if (pid_fils == -1){
    perror("creation du fils impossible");
    exit(EXIT_FAILURE);
  }
    
  if (pid_fils != 0) { /* Code affecté au pere */
    close(tube[0]); // Fermeture descripteur en lecture 
    /* Attente et récupération entier de l'utilisateur */
    printf("Veuillez entrer un entier : \n");
    scanf("%d", &entier);
    /* Ecriture dans le tube */
    write(tube[1], &entier, sizeof(int));
    close(tube[1]); // Fermeture du descripteur en ecriture 
    wait(NULL);	// Attente de la terminaison du processus fils
    exit(EXIT_SUCCESS);
  }
  else { /* Code affecté au fils */
    close(tube[1]); // Fermeture descripteur en ecriture 
    /* Lecture du tube dans le tube, calcul du carré */
    read(tube[0], &entier, sizeof(int));  // Lecture de l'entier
    printf("Entier : %d\n", entier);  // Affichage sur stdout 
    printf("Carré : %d\n", entier * entier); // Affichage sur stdout 
    close(tube[0]); // Fermeture du descripteur en lecture 
    exit(EXIT_SUCCESS);
  }
}
