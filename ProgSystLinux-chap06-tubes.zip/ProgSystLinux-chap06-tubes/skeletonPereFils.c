/********************************
 * Fichier skeletonPereFils.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h>		// printf
#include <stdlib.h>		// EXIT_SUCCESS, EXIT_FAILURE
#include <unistd.h>		// fork, exit, pipe, close, write, read
#include <string.h>		// strlen
#include <sys/wait.h>		// wait

int main(void) {
  /* Déclaration de variables */
  int tube[2]; // Tube à créer
  int valRetour; // Pour valeur de retour d'appel de pipe
  char buffer[5]; // Pour stocker les données lues
  pid_t pid_fils = -1; // Pour récupérer le pid du fils 

  /* Creation du tube */
  // A COMPLETER
  // ATTENTION, LE TUBE ANONYME DOIT ETRE
  // CREE AVANT LE PROCESSUS FILS

  /* Création du processus fils */
  pid_fils = fork();
  if (pid_fils == -1){
    perror("creation du fils impossible");
    exit(EXIT_FAILURE);
  }
  
  if (pid_fils != 0) {
    /* Code affecté au processus pere */
    fprintf(stdout, "Je suis le pere (pid:%d)\n", getpid());
    // A COMPLETER
    wait(NULL);	/* Attente de la terminaison du processus fils */
    exit(EXIT_SUCCESS); // fin code père
  } else {
    /* Code affecté au processus fils */
    fprintf(stdout, "Je suis le fils (pid:%d, ppid:%d) \n", getpid(), getppid());
    // A COMPLETER
    exit(EXIT_SUCCESS); // fin code fils
  }
} // fin main
