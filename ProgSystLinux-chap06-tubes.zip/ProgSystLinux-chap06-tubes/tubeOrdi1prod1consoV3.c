/********************************
 * Fichier tubeOrdi1prod1consoV3.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h>		// printf
#include <stdlib.h>		// EXIT_SUCCESS, EXIT_FAILURE
#include <unistd.h>		// fork, exit, pipe, close, write, read
#include <string.h>		// strlen
#include <sys/wait.h>		// wait

int main(void) {
  /* Déclaration de variables */
  int tube[2]; // Tube à créer
  int valRetour; // Pour valeur de retour d'appel de pipe
  char buffer; // Pour stocker les données lues
  pid_t pid_fils; // Pour récupérer le pid du fils 

  /* Creation du tube */
  valRetour = pipe(tube);
  if (valRetour == -1) {
    perror("creation du tube impossible");
    exit(EXIT_FAILURE);
  }

  /* Création du processus fils */
  pid_fils = fork();
  if (pid_fils == -1){
    perror("creation du fils impossible");
    exit(EXIT_FAILURE);
  }

  if (pid_fils != 0) {
    /* Code affecté au processus pere */
    close(tube[0]); 
    sleep(10); // <- AJOUT ICI (SLEEP 10 sec AVT ECRITURE)
    char *chapeaux = "Ils ont des chapeaux ronds, Vive la Bretagne!";
    write(tube[1], chapeaux, strlen(chapeaux)); 
    close(tube[1]); 
    wait(NULL);	
    exit(EXIT_SUCCESS); 
  } else {
    /* Code affecté au processus fils */
    close(tube[1]); 
    printf("fils : je suis créé, je demande à lire maintenant\n");
    // A l'EXECUTION, LE PREMIER APPEL DE READ CI-DESSOUS BLOQUE EN ATTENDANT l'ECRITURE DU PERE 
    while (read(tube[0], &buffer, 1) > 0) {
      fprintf(stdout, "%s", &buffer); 
    }
    fprintf(stdout, "\n");
    close(tube[0]); 
    exit(EXIT_SUCCESS); 
  }
} // fin main
