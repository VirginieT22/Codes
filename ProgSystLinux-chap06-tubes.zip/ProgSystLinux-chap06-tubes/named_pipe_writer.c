/********************************
 * Fichier named_pipe_writer.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h>
#include <stdlib.h> 
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h> // pour tubes nommés
#include <sys/stat.h> // pour tubes nommés

int main(){
  int tub_nomme; // Pour descripteur tube
  int retourValue; // Pour valeurs retour

  /* Suppression du tube si déjà existant */
  retourValue = unlink("my_named_pipe");
  if (retourValue==0){ printf("Ancien tube supprimé (RAZ)\n"); }
	
  /* Creation du tube nomme */
  retourValue = mkfifo("my_named_pipe", 0640);
  if (retourValue == -1) {
    perror("Tube probablement déjà existant (on travaille avec)\n");
    exit(EXIT_SUCCESS);
  }
	
  // A ce  niveau, si lance la commande ls, on s'aperçoit de la creation
  // d'un fichier nommé my_named_pipe de type fifo dans le repertoire courant

  /* Ouverture du tube pour écriture */
  tub_nomme = open("my_named_pipe", O_WRONLY);
  if (tub_nomme == -1) {
    perror("Ouverture du tube impossible dans le processus ecrivain\n");
    return EXIT_FAILURE;
  }

  /* Ecriture dans le tube */
  printf("Ecriture de la première phrase\n");
  write(tub_nomme, "Ils ont des chapeaux ronds, Vive la Bretagne", 44);
  sleep(4); // Attente de 4 sec, laisse le temps de voir ce qui se passe
  printf("Ecriture de la seconde phrase\n");
  write(tub_nomme, "Ils ont des tonneaux ronds, Vive les Bretons", 44);

  /* Fermeture du tube */
  close(tub_nomme);

  return EXIT_SUCCESS; // The end... for the writer
}
