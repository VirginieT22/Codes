/********************************
 * Fichier tubeOrdi1prod2conso.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h>		// printf
#include <stdlib.h>		// EXIT_SUCCESS, EXIT_FAILURE
#include <unistd.h>		// fork, exit, pipe, close, write, read
#include <string.h>		// strlen
#include <sys/wait.h>		// wait

int main(void){
  /* Déclaration de variables */
  int tube[2]; // Tube à créer
  int valRetour; // Pour valeur de retour d'appel de pipe
  char buffer; // Pour stocker les données lues
  pid_t pid_fils1, pid_fils2; // Pour récupérer le pid du fils 

  /* Creation du tube */
  valRetour = pipe(tube);
  if (valRetour == -1) {
    perror("creation du tube impossible");
    exit(EXIT_FAILURE);
  }

  pid_fils1 = fork();	// Création du premier fils
  if (pid_fils1 == 0) {	/* Code affecté au premier fils */
    close(tube[1]); // Fermeture du descripteur en écriture
    /* Lecture dans tube, caractère par caractère avec écriture sur terminal */
    while (read(tube[0], &buffer, 1) > 0) {// Tant qu'on peut lire, on lit...
      fprintf(stdout, "fils 1 : %c\n", buffer); //... et on affiche
    }
    fprintf(stdout, "\n");
    close(tube[0]); // Fermeture du descripteur en lecture
    exit(EXIT_SUCCESS); // Fin du code associé au premier fils
  }

  pid_fils2 = fork();	// Création du second fils
  if (pid_fils2 == 0) {	/* Code affecté au second fils */
    close(tube[1]); // Fermeture du descripteur en écriture
    /* Lecture dans tube, caractère par caractère avec écriture sur terminal */
    while (read(tube[0], &buffer, 1) > 0) {// Tant qu'on peut lire, on lit...
      fprintf(stdout, "fils 2 : %c\n", buffer); //... et on affiche
    }
    fprintf(stdout, "\n");
    close(tube[0]); // Fermeture du descripteur en lecture
    exit(EXIT_SUCCESS); // Fin du code associé au second fils
  }

  /* La suite du code est associée au père */
  close(tube[0]); // Fermeture du descripteur en lecture
  char *chapeaux = "Ils ont des chapeaux ronds, Vive la Bretagne !";
  write(tube[1], chapeaux, strlen(chapeaux)); // Ecriture
  close(tube[1]); // Fermeture du descripteur en écriture
  wait(NULL); // Attente terminaison du premier des deux fils se terminant */
  wait(NULL); // Attente terminaison du second des deux fils se terminant */
  exit(EXIT_SUCCESS); 
} // Fin main
