/********************************
 * Fichier tubeOrdiBidirectionnel.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
/* David Guennec a participé à l'élaboration de cette solution. Merci David. */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

int main(void){
  /* Déclaration de variables */
  int tubeDataFils2[2]; // le fils 2 va y écrire et le fils 1 va y lire
  int tubeDataFils1[2]; // le fils 1 va y écrire et le fils 2 va y lire
  int valRetour; // Pour valeur de retour des appels de pipe
  char buffer1[50]; // Attention à la taille
  char buffer2[50]; // Attention à la taille
  ssize_t nb_lus; // Nombre d'octets lus en retour de read
  pid_t pidfils1 = -1; // pid du premier fils créé
  pid_t pidfils2 = -1; // pid du second fils créé

  /* Creation des tubes */
  valRetour=pipe(tubeDataFils1);
  if (valRetour == -1) {
    printf("tubeDataFils1 non créé"); return EXIT_FAILURE;
  }
  valRetour=pipe(tubeDataFils2);
  if (valRetour == -1) {
    printf("tubeDataFils2 non créé"); return EXIT_FAILURE;
  }

  pidfils1 = fork();	// Création du premier fils
  if (pidfils1 == 0) {	/* Code affecté au premier fils */
    close(tubeDataFils2[1]); // Fermeture descripteur écriture tubeDataFils2
    close(tubeDataFils1[0]); // Fermeture descripteur lecture tubeDataFils1
    /* Ecriture dans tubeDataFils1 */
    // Attention à commencer par ecrire chez l'un des deux fils (interblocage)
    char* reve = "J'ai encore rêvé d'elle";
    write(tubeDataFils1[1], reve, strlen(reve));
    fprintf(stdout,"Fils1 (pid:%d) : J'ai écrit dans tubeDataFils1\n",getpid());
    /* Lecture de tubeDataFils2 */
    nb_lus = read(tubeDataFils2[0], &buffer1, sizeof(buffer1));
    buffer1[nb_lus]='\0';
    printf("\"%s\" bien recu par le fils 1 (pid :%d), %zu octets lus\n", buffer1, getpid(), nb_lus);
    /* Fermeture des descripteurs et sortie du programme */
    close(tubeDataFils2[0]);
    close(tubeDataFils1[1]);
    exit(EXIT_SUCCESS); // Fin code premier fils
  }

  pidfils2 = fork();	// Création du second fils
  if (pidfils2 == 0) {	/* Code affecté au second fils */
    close(tubeDataFils1[1]); // Fermeture descripteur écriture tubeDataFils1
    close(tubeDataFils2[0]); // Fermeture descripteur lecture tubeDataFils2
    /* Ecriture dans tubeDataFils2 */
    // Attention à commencer par ecrire chez l'un des deux fils (interblocage)
    char* dormi="J'ai mal dormi";
    write(tubeDataFils2[1], dormi, strlen(dormi));
    fprintf(stdout,"Fils2 (pid:%d) : J'ai écrit dans tubeDataFils2\n",getpid());
    /* Lecture du tubeDataFils1 */
    nb_lus = read(tubeDataFils1[0], &buffer2, sizeof(buffer2));
    buffer2[nb_lus]='\0';
    printf("\"%s\" bien recu par le fils 2 (pid :%d), %zu octets lus\n", buffer2, getpid(), nb_lus);
    /* Fermeture des descripteurs et sortie du programme */
    close(tubeDataFils1[0]);
    close(tubeDataFils2[1]);
    exit(EXIT_SUCCESS); // Fin code second fils
  }
  // Le père termine proprement le programme
  wait(NULL);
  wait(NULL);
  exit(EXIT_SUCCESS);
}
