/********************************
 * Fichier tubeOrdiSimpleTube.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h>		// printf
#include <stdlib.h>		// EXIT_SUCCESS, EXIT_FAILURE
#include <unistd.h>		// fork, exit, pipe, close, write, read
#include <string.h>		// strlen
#include <sys/wait.h>		// wait

int main(void) {
  /* Déclaration de variables */
  int tube[2]; // Tube à créer
  int valRetour; // Pour valeur de retour d'appel de pipe
  char buffer[5]; // Pour stocker les données lues
  pid_t pid_fils; // Pour récupérer le pid du fils 

  /* Creation du tube */
  valRetour = pipe(tube);
  if (valRetour == -1) {
    perror("creation du tube impossible");
    exit(EXIT_FAILURE);
  }

  /* Création du processus fils */
  pid_fils = fork();
  if (pid_fils == -1){
    perror("creation du fils impossible");
    exit(EXIT_FAILURE);
  }

  if (pid_fils != 0) {
    /* Code affecté au processus pere */
    close(tube[0]); // Fermeture du descripteur en lecture
    fprintf(stdout, "pere (pid:%d) J'écris \"Hello\"\n", getpid());
    write(tube[1], "Hello", 5); // Ecriture dans tube
    close(tube[1]); // Fermeture du descripteur en écriture
    wait(NULL);	/* Attente de la terminaison du processus fils */
    exit(EXIT_SUCCESS); // fin code père
  } else {
    /* Code affecté au processus fils */
    close(tube[1]); // Fermeture du descripteur en écriture
    read(tube[0], buffer, 5); // Lecture dans tube
    fprintf(stdout, "fils (pid:%d, ppid:%d) J'ai récupéré \"%s\"\n", getpid(), getppid(), buffer);
    close(tube[0]); // Fermeture du descripteur en lecture
    exit(EXIT_SUCCESS); // fin code fils
  }
} // fin main
