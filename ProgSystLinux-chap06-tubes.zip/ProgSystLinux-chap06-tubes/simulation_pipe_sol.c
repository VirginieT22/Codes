/********************************
 * Fichier simulation_pipe_sol.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>

int main (int argc, char *argv[])
{
  int tube1[2], tube2[2];
  char *cmd1[3] = { argv[1], argv[2], NULL };
  char *cmd2[3] = { argv[3], argv[4], NULL };
  char *cmd3[3] = { argv[5], argv[6], NULL };
  if (argc != 7)
    {
      fprintf (stderr, "Usage : %s ...\n", argv[0]);
      exit (EXIT_FAILURE);
    }
  pipe (tube1);
  pipe (tube2);
  if (fork () == 0) { // Code premier fils pour cmd1
    close (tube1[0]); // N'utilise pas la sortie du tube 1
    /* La sortie standard devient l'entrée du tube 1 : */
    dup2 (tube1[1], STDOUT_FILENO);
    close (tube2[0]); // N'utilise pas la sortie du tube 2
    close (tube2[1]); // N'utilise pas l'entrée du tube 2
    execvp (cmd1[0], cmd1); // Exécute cmd1
  }
  else if (fork () == 0) { // Code deuxième fils pour cmd2
    /* L'entrée standard devient la sortie du tube 1 : */
    dup2 (tube1[0], STDIN_FILENO);
    close (tube1[1]); // N'utilise pas l'entrée du tube 1
    close (tube2[0]); // N'utilise pas la sortie du tube 2
    /* La sortie standard devient l'entrée du tube 2 : */
    dup2 (tube2[1], STDOUT_FILENO);
    execvp (cmd2[0], cmd2); // Exécute cmd2
  }
  else if (fork () == 0) { // Code troisième fils pour cmd3
    close (tube1[0]); // N'utilise pas la sortie du tube 1
    close (tube1[1]); // N'utilise pas l'entrée du tube 1
    /* L'entrée standard devient la sortie du tube 2 : */
    dup2 (tube2[0], STDIN_FILENO);
    close (tube2[1]); // N'utilise pas l'entrée du tube 2
    execvp (cmd3[0], cmd3); // Exécute cmd3 
  }
  else { /* Code associé au père */
    close (tube1[0]); // Fermeture descripteur 1/4
    close (tube1[1]); // Fermeture descripteur 2/4
    close (tube2[0]); // Fermeture descripteur 3/4
    close (tube2[1]); // Fermeture descripteur 4/4
    wait (NULL); // Attente d'un fils 1/3
    wait (NULL); // Attente d'un fils 2/3
    wait (NULL); // Attente d'un fils 3/3
  }
  return EXIT_SUCCESS;
}
