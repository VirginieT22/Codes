/********************************
 * Fichier recherche_tableau_entier_k_fils.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <errno.h>		/* errno */
#include <stdio.h>		/* stderr, stdout, fprintf */
#include <stdlib.h>		/* exit */
#include <unistd.h>		/* fork, getpid, getppid, ... */

#define N_MAX 255

   /**
     * @brief réserve la mémoire pour n valeurs entières
     * @param entier n nombre de cases mémoire à réserver
     * @return adresse du tableau
     */
int *creer_tableau_vide_entier(unsigned int n)
{
	int *tableau = (int *)malloc(n * sizeof(int));

	if (tableau == NULL) {
		fprintf(stderr, "Exception, mémoire insuffisante\n");
		exit(EXIT_FAILURE);
	} else {
		return tableau;
	}
}

   /**
     * @brief lis sur l'entrée standard 1 valeur entière et la stocke dans un tableau, dans une case précise
     * @param tableau d'entier, indice de la case destination
     */
void remplir_case_entier(int *tableau, unsigned int i)
{
	fprintf(stdout, "élément %d : ", i);
	scanf("%d", &(tableau[i]));	// FIXME : comportement si on rentre un non entier ?
}

   /**
     * @brief lis sur l'entrée standard n valeur entières et les stockent dans un tableau
     * @param entier n nombre de cases mémoire du tableau, tableau d'entier
     */
void remplir_tableau_entier(unsigned int n, int *tableau)
{
	unsigned int i;

	for (i = 0; i < n; i++) {
		remplir_case_entier(tableau, i);
	}
}

   /**
     * @brief recherche une valeur dans un tableau d'entier sur une plage d'indices 
     * @param entier val valeur à rechercher, tableau d'entier, indice de début de zone de recherche inclu, indice de fin de zone de recherche exclu
     */
void rechercher_tableau_entier(int val, int *tableau, unsigned int d, unsigned int f)
{
	unsigned int i;

	for (i = d; i < f; i++) {
		if (val == tableau[i]) {
			fprintf(stdout, "Processus %d a TROUVE !\n", getpid());
			exit(EXIT_SUCCESS);
		}
	}
}

   /**
     * @brief recherche sur 2 fils dans un tableau d'entier
     */
int main()
{
	unsigned int n;
	int *tableau;
	int val;
	unsigned int i, k;

	fprintf(stdout, "Taille du tableau à renseigner : ");
	scanf("%u", &n);

	tableau = creer_tableau_vide_entier(n);
	remplir_tableau_entier(n, tableau);

	printf("Elément à rechercher : ");
	scanf("%d", &val);

	printf("Nombre de fils à lancer : ");
	scanf("%u", &k);

	for (i = 0; i < k; i++) {
		switch (fork()) {	/* Duplique le processus */
		case -1:
			fprintf(stderr,
				"fork()  impossible, errno=%d (fichier %s ligne %d)\n",
				errno, __FILE__, __LINE__);
			exit(EXIT_FAILURE);
		case 0:	/* Execute pour le ième fils */

			fprintf(stdout,
				"Fils %d(PID %d) : Je vais rechercher %d dans la tranche [%d, %d[ du tableau\n",
				i + 1, getpid(), val, i * n / k, (i + 1) * n / k);
			/* le fils s'interrompt dans la fonction avec EXIT_SUCCESS s'il trouvé l'élément
			 * la fonction est passante si non
			 */
			rechercher_tableau_entier(val, tableau, i * n / k, (i + 1) * n / k);
			exit(EXIT_FAILURE);

		default:	/* Execute pour le pere */
			break;
		}
	}

	exit(EXIT_SUCCESS);
}
