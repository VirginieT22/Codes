/********************************
 * Fichier capture_signaux_gest.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h>		// fprintf
#include <signal.h>		// signal
#include <unistd.h>		// pause
#include <string.h>		// strsignal

void nouveauGestionnaire(int); // Défini à la fin du fichier

int main(void){
	int numSignal;
	// Pour récupérer la valeur retour de la primitive signal
	typedef void (*sighandler_t) (int);
	sighandler_t returnValueSignal;
	// Pour chaque signal (ici on peut utiliser la valeur plutôt que le nom symbolique puisqu'on ne distingue pas les signaux)
	for (numSignal = 1; numSignal < 32; numSignal++)
	  { // Associer (si possible) le nouveau gestionnaire de signal
	    returnValueSignal = signal(numSignal, nouveauGestionnaire);
	    if (returnValueSignal == SIG_ERR) {
	      fprintf(stderr, "Signal %d non capturé\n", numSignal);
	    }
	  }
	// L'instruction suivante ne doit pas être utilisée "dans la vraie vie". Employée ici pour des raisons pédagogiques, elle permet au programme de se (re)placer en attente d'un signal de façon illimitée.
	while (1) {pause();}
}

  // Nouveau gestionnaire de signal
void nouveauGestionnaire(int numSignal) { // numSignal est instancié à l'execution par signal déclencheur
	fprintf(stderr, "(%d) J'ai reçu le signal %d (%s), mais je n'adopte pas le comportement par défaut qui lui est associé. \n", getpid(), numSignal, strsignal(numSignal));
}
