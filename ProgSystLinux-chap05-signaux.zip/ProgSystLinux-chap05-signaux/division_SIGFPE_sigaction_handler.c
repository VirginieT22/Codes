/********************************
 * Fichier division_SIGFPE_sigaction_handler.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h>		// fprintf
#include <stdlib.h>		// atoi, EXIT_SUCESS, EXIT_FAILURE
#include <string.h>		// strsignal
#include <unistd.h>		// getpid, exit
#include <signal.h>		// sigaction, sigemptyset

void nouveauGestionnaire(int);

int main(int argc, char *argv[]) {
	int num, denom;
	struct sigaction new_action;
	struct sigaction old_action;
	int return_value_sigaction;

	// Remplissage de la structure sigaction pour le nouveau gestionnaire
	new_action.sa_handler = nouveauGestionnaire; // nouveau gestionnaire de signal
	sigemptyset(&(new_action.sa_mask)); // liste des signaux bloqués pendant l'exécution de sa_handler, vidée
	sigaddset(&(new_action.sa_mask), SIGFPE); // Implicitement effectué par défaut
	new_action.sa_flags = SA_RESETHAND; // Rétablit SIG_DFL après une réception

	if (argc != 3) {
		printf("Syntaxe : %s nunerateur denominateur \n", argv[0]);
		exit(EXIT_FAILURE);
	}

	num = atoi(argv[1]); // recup numérateur en type entier
	denom = atoi(argv[2]); // recup dénominateur en type entier

	// Affectation du nouveau gestionnaire à SIGFPE via sigaction
	return_value_sigaction = sigaction(SIGFPE, &new_action, &old_action);
	if (return_value_sigaction != 0) {
		fprintf(stderr, "SIGFPE non capturé\n");
	}
	printf("Le résultat de %d/%d est %d, et le reste est %d.\n", num, denom, num / denom, num % denom);
	exit(EXIT_SUCCESS);
}

// Definition du nouveau gestionnaire de signal, celui-ci a pour paramètre le signal l'ayant déclenché
void nouveauGestionnaire(int numSignal) {
	fprintf(stderr, "(%d) Division par 0 impossible (j'ai reçu le signal %s). \n", getpid(), strsignal(numSignal));
}
