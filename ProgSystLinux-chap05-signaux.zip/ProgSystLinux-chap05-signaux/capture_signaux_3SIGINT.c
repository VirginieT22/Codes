/********************************
 * Fichier capture_signaux_3SIGINT.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h>		// fprintf
#include <signal.h>		// signal
#include <unistd.h>		// pause
#include <string.h>		// strsignal
#include <stdlib.h>		// exit

void capture2fois(int); // Définie après main
int nbSIGINT = 0; // Variable nécessairement de portée globale

int main(void) {
	// Pour récupérer la valeur retour de la primitive signal
	typedef void (*sighandler_t) (int);
	sighandler_t return_value_signal;
	// Affectation nouveau gestionnaire
	return_value_signal = signal(SIGINT, capture2fois);
	if (return_value_signal == SIG_ERR) {
		fprintf(stderr, "Signal SIGINT non capturé\n");
	}
	// L'instruction suivante ne doit pas être utilisée "dans la vraie vie". Employée ici pour des raisons pédagogiques, elle permet de faciliter l'expérimentation
	while (1) { pause(); }
	return EXIT_SUCCESS;
}

// Code du nouveau gestionnaire 
void capture2fois(int numSignal) { 
	nbSIGINT++;
	fprintf(stderr, "(%d) Et de %d ... \n", getpid(), nbSIGINT);
	if (nbSIGINT == 3) {
		fprintf(stderr, "(%d) Je sors ! \n", getpid()); exit(EXIT_SUCCESS);
	}
}
