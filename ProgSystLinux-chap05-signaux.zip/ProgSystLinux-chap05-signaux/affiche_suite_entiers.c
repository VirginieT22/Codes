/********************************
 * Fichier affiche_suite_entiers.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h>		// fprintf
#include <unistd.h>		// sleep
#include <stdlib.h>		// exit

int main(void)
{
	int i;
	for (i = 1; i < 31; i++) {
		printf("%d\n", i);
		sleep(1);
	}
	exit(EXIT_SUCCESS);
}
