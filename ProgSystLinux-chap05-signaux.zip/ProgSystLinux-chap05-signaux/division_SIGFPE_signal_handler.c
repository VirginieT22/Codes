/********************************
 * Fichier division_SIGFPE_signal_handler.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h>		// fprintf
#include <stdlib.h>		// atoi, EXIT_SUCESS, EXIT_FAILURE
#include <signal.h>		// signal
#include <string.h>		// strsignal
#include <unistd.h>		// getpid, exit

void nouveauGestionnaire(int); // Defini après main

int main(int argc, char *argv[]) {
	int num, denom; 
	// Pour récupérer la valeur retour de la primitive signal
	typedef void (*sighandler_t) (int);
	sighandler_t return_value_signal;
	
	if (argc != 3) {
		printf("Syntaxe : %s nunerateur denominateur \n", argv[0]);
		exit(EXIT_FAILURE);
	}
	
	num = atoi(argv[1]); // recup numérateur en type entier
	denom = atoi(argv[2]); // recup dénominateur en type entier
	
	// Affectation du nouveau gestionnaire à SIGFPE via signal
	return_value_signal = signal(SIGFPE, nouveauGestionnaire);
	if (return_value_signal == SIG_ERR) {
		fprintf(stderr, "SIGFPE non capturé\n");
	}
	printf("Le résultat de %d/%d est %d, et le reste est %d.\n", num, denom,
	       num / denom, num % denom);
	exit(EXIT_SUCCESS);
}

void nouveauGestionnaire(int numSignal) {
	fprintf(stderr, "(%d) Division par 0 impossible (j'ai reçu le signal %s). \n", getpid(), strsignal(numSignal));
}
