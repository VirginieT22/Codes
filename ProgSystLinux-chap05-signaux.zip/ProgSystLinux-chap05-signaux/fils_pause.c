/********************************
 * Fichier fils_pause.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <sys/types.h>		// getpid
#include <unistd.h>		// pause, fork, exit, getpid
#include <stdio.h>		// fprintf
#include <sys/wait.h>		// wait
#include <stdlib.h>		// exit
#include <string.h>		// strsignal

void nouveauGestionnaire(int);

int main(void) {
	pid_t pid_fils;
	pid_t return_value_wait;
	int status;
	
	pid_fils = fork(); //Création du processus fils
	if (pid_fils == 0) { // Code affecté au fils
		signal(SIGUSR1, nouveauGestionnaire); // Gestionnaire pour SIGUSR1
		fprintf(stdout, "Je suis le fils (PID %d). Attente signal.\n", getpid());
		pause();
		fprintf(stdout, "Merci à vous, je vous quitte\n");
		exit(EXIT_SUCCESS);
	} else { // Code affecté au père
		return_value_wait = wait(&status); // Pour l'instant, status non exploité
		if (return_value_wait == -1) {
			perror("waitpid"); exit(EXIT_FAILURE);
		}
		exit(EXIT_SUCCESS);
	}
}

// Definition du nouveau gestionnaire 
void nouveauGestionnaire(int numSignal) {
	fprintf(stderr, "(%d) J'ai capturé le signal %s (%d). \n", getpid(), strsignal(numSignal), numSignal);
}
