/********************************
 * Fichier division.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h>		// fprintf
#include <stdlib.h>		// atoi, EXIT_SUCESS, EXIT_FAILURE
#include <unistd.h>		// getpid, exit

void nouveauGestionnaire(int);

int main(int argc, char *argv[])
{
	int num, denom;

	if (argc != 3) {
		printf("Syntaxe : %s entier_nunerateur entier_denominateur \n", argv[0]);
		exit(EXIT_FAILURE);
	}

	num = atoi(argv[1]);
	denom = atoi(argv[2]);

	printf("Le résultat de %d/%d est %d, et le reste est %d.\n", num, denom, num / denom, num % denom);
	exit(EXIT_SUCCESS);
}
