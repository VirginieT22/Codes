/********************************
 * Fichier revise_tes_tables_signal.c
 * Livre "Programmation d'applications système sous Linux"
 *
 * P. Alain, J. Chevelu, S. Le Maguer, V. Thion, B. Vozel
 *
 ********************************/
#include <stdio.h>		// fprintf, scanf
#include <stdlib.h>		// atoi, EXIT_SUCESS, EXIT_FAILURE, srand, rand
#include <signal.h>		// signal
#include <string.h>		// strsignal
#include <unistd.h>		// getpid, exit
#include <time.h>		// time
#include <unistd.h>		// alarm

// Affichage de la réponse "juste"
void affiche_reponse(); // Définie après le main
// Nouveau gestionnaire de signal à affectuer à SIGFPE
void nouveau_gestionnaire(int); // Définie après le main

int a, b, solution; // Variables nécessairement de portée globale

int main(int argc, char *argv[]) {
	int reponse;
	// Pour récupérer la valeur retour de la primitive signal
	typedef void (*sighandler_t) (int);
	sighandler_t return_value_signal;
	// Test arguments proposés par l'utilisateur
	if ((argc != 2) || (atoi(argv[1])<1)) {
		printf("Syntaxe : %s sec \noù sec est le temps limite en sec (>0). \n", argv[0]);
		exit(EXIT_FAILURE);
	}
	// Tirage aléatoire des deux nombres
	srand((unsigned int)time(NULL)); // Nouvelle graine
	a = rand() % 11;
	b = rand() % 11;
	solution = a * b;
	// Affectation nouveau gestionnaire à SIGALRM
	return_value_signal = signal(SIGALRM, nouveau_gestionnaire);
	if (return_value_signal == SIG_ERR) {
		fprintf(stderr, "Erreur programme : Signal SIGALRM non capturé\n");
	}
	// Affectation nouveau gestionnaire à SIGINT
	return_value_signal = signal(SIGINT, nouveau_gestionnaire);
	if (return_value_signal == SIG_ERR) {
		fprintf(stderr, "Erreur programme : Signal SIGINT non capturé\n");
	}
	// Armement de l'alarme
	alarm((unsigned int)atoi(argv[1])); 
	// Interrogation de l'utilisateur
	fprintf(stdout, "Quel est le résultat de %d x %d ? Tu as %d secondes pour répondre, c'est parti ! \n", a, b, atoi(argv[1]));
	// Attente et lecture de la réponse de l'utilisateur
	if (atoi(argv[1]) != 0) { scanf("%d", &reponse); }
	// Tests de la réponse founie par l'utilisateur
	if (reponse == solution) {
		fprintf(stdout, "Bravo !\n");
	} else {
		fprintf(stdout, "Faux ! ");
		affiche_reponse();
	}
	exit(EXIT_SUCCESS);
} // Fin du main

// Affichage de la réponse
void affiche_reponse() {
	fprintf(stdout, "La solution de %d x %d est : %d \n", a, b, solution);
}

// Nouveau gestionnaire
void nouveau_gestionnaire(int numSignal) {
	// On aurait pu déclarer deux procédures gestionnaires différentes 
	switch (numSignal) {
	case SIGALRM:{
			fprintf(stdout, "Réception de %s -> Trop tard, temps limite écoulé \n", strsignal(numSignal));
			affiche_reponse();
			exit(EXIT_SUCCESS);	// L'utilisateur est en erreur mais pas le programme
			break;
		}
	case SIGINT:{
			fprintf(stdout, "Réception de %s -> Tu donnes ta langue au chat \n", strsignal(numSignal));
			affiche_reponse();
			exit(EXIT_SUCCESS);	// L'utilisateur est en erreur mais pas le programme
			break;
		}
	}
}
